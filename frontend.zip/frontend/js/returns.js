/* ==================== SALES RETURNS & CUSTOMER REFUNDS EXTENSION ==================== */
SalesModule.prototype.renderReturnsView = function() {
  const returns = storage.getReturns();
  const settings = storage.getSettings();

  const countElem = document.getElementById('ret-kpi-count');
  const amountElem = document.getElementById('ret-kpi-amount');
  const unitsElem = document.getElementById('ret-kpi-units');

  const totalCount = returns.length;
  const totalAmount = returns.reduce((a, b) => a + (b.totalRefundAmount || 0), 0);
  let totalUnits = 0;
  returns.forEach(r => {
    (r.items || []).forEach(item => { totalUnits += (parseInt(item.returnQty) || 0); });
  });

  if (countElem) countElem.textContent = totalCount;
  if (amountElem) amountElem.textContent = Utils.formatCurrency(totalAmount, settings.currency);
  if (unitsElem) unitsElem.textContent = `${totalUnits} Units`;

  this.renderReturnsHistoryTable(returns);
};

SalesModule.prototype.renderReturnsHistoryTable = function(returnsList) {
  const tbody = document.getElementById('returns-history-tbody');
  if (!tbody) return;
  const settings = storage.getSettings();

  if (!returnsList || !returnsList.length) {
    Utils.emptyTable(tbody, 8, 'No sales returns or refunds recorded yet.');
    return;
  }

  let html = '';
  returnsList.slice().reverse().forEach(r => {
    const itemsSummary = (r.items || []).map(i => `${i.name} (${i.returnQty}x)`).join(', ');
    html += `
    <tr>
      <td><strong style="color: var(--primary);">${r.returnNumber}</strong></td>
      <td><span style="font-weight: 700; color: #475569;">${r.invoiceNumber}</span></td>
      <td>${r.date} <span style="font-size: 0.75rem; color: var(--text-muted);">${r.time || ''}</span></td>
      <td><div style="font-weight: 700;">${r.customerName}</div></td>
      <td><div style="max-width: 260px; font-size: 0.82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${itemsSummary}">${itemsSummary}</div></td>
      <td style="font-weight: 800; color: #ef4444;">${Utils.formatCurrency(r.totalRefundAmount, settings.currency)}</td>
      <td>${Utils.badge(r.reason || 'Customer Return')}</td>
      <td>
        <div style="display: flex; gap: 6px;">
          <button class="btn-secondary-myu btn-sm-myu" onclick="salesModule.viewReturnDetailsModal('${r.id}')" title="View Details / Receipt"><i class="fa-solid fa-eye"></i></button>
          <button class="btn-danger-myu btn-sm-myu" onclick="salesModule.deleteReturn('${r.id}')" title="Delete Return"><i class="fa-solid fa-trash-can"></i></button>
        </div>
      </td>
    </tr>
  `;
  });
  tbody.innerHTML = html;
};

SalesModule.prototype.filterReturnsHistory = function() {
  const searchInput = document.getElementById('ret-search');
  const query = searchInput ? (searchInput.value || '').toLowerCase().trim() : '';
  const returns = storage.getReturns();
  if (!query) {
    this.renderReturnsHistoryTable(returns);
    return;
  }
  const filtered = returns.filter(r => {
    const itemsStr = (r.items || []).map(i => (i.name || '') + ' ' + (i.itemNo || '')).join(' ').toLowerCase();
    return (r.returnNumber || '').toLowerCase().includes(query) ||
      (r.invoiceNumber || '').toLowerCase().includes(query) ||
      (r.customerName || '').toLowerCase().includes(query) ||
      (r.reason || '').toLowerCase().includes(query) ||
      itemsStr.includes(query);
  });
  this.renderReturnsHistoryTable(filtered);
};

SalesModule.prototype.viewReturnDetailsModal = function(returnId) {
  const returns = storage.getReturns();
  const ret = returns.find(r => r.id === returnId);
  if (!ret) return;

  const settings = storage.getSettings();
  const container = document.getElementById('return-details-modal-content');
  if (!container) return;

  let itemsHtml = '';
  (ret.items || []).forEach(item => {
    itemsHtml += `
    <tr>
      <td><strong>${item.name}</strong></td>
      <td>${item.returnQty}</td>
      <td>${Utils.formatCurrency(item.unitPrice, settings.currency)}</td>
      <td style="font-weight: 700; color: #ef4444;">${Utils.formatCurrency(item.lineRefund, settings.currency)}</td>
    </tr>
  `;
  });

  container.innerHTML = `
  <div style="padding: 8px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid var(--primary); padding-bottom: 12px; margin-bottom: 16px;">
      <div>
        <h2 style="color: var(--primary); margin: 0; font-size: 1.25rem;">${settings.shopName || 'MYU Wholesale'}</h2>
        <div style="font-size: 0.8rem; color: var(--text-muted);">SALES RETURN & REFUND VOUCHER</div>
      </div>
      <div style="text-align: right;">
        <h3 style="margin: 0; font-size: 1.1rem; color: #ef4444;">${ret.returnNumber}</h3>
        <div style="font-size: 0.78rem; color: var(--text-muted);">Ref Invoice: <strong>${ret.invoiceNumber}</strong></div>
        <div style="font-size: 0.78rem; color: var(--text-muted);">Date: ${ret.date} ${ret.time || ''}</div>
      </div>
    </div>

    <div style="background: #f8fafc; padding: 12px; border-radius: 6px; margin-bottom: 16px; font-size: 0.85rem;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
        <span><strong>Customer:</strong> ${ret.customerName}</span>
        <span><strong>Refund Method:</strong> ${ret.paymentMethod || 'Cash'}</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span><strong>Reason:</strong> ${ret.reason || 'Customer Return'}</span>
        <span><strong>Notes:</strong> ${ret.notes || 'None'}</span>
      </div>
    </div>

    <table class="custom-table" style="font-size: 0.85rem; margin-bottom: 16px;">
      <thead>
        <tr>
          <th>Returned Product</th>
          <th>Qty</th>
          <th>Net Unit Price</th>
          <th>Refund Subtotal</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 2px solid var(--border-color); padding-top: 12px; margin-top: 12px;">
      <div>
        <span style="font-weight: 700; color: #991b1b; font-size: 0.9rem;">Total Refund Issued:</span>
      </div>
      <div style="font-size: 1.25rem; font-weight: 800; color: #ef4444;">
        ${Utils.formatCurrency(ret.totalRefundAmount, settings.currency)}
      </div>
    </div>
  </div>
  `;

  const appObj = window.app || (typeof app !== 'undefined' ? app : null);
  if (appObj) appObj.openModal('return-details-modal');
};

window.openProcessReturnModal = function(saleId = null) {
  const module = window.salesModule || (typeof salesModule !== 'undefined' ? salesModule : null);
  if (module && typeof module.openReturnModal === 'function') {
    module.openReturnModal(saleId);
  } else if (window.app && typeof window.app.openModal === 'function') {
    window.app.openModal('return-modal');
  } else {
    const m = document.getElementById('return-modal');
    if (m) { m.style.display = 'flex'; m.classList.add('show'); }
  }
};
