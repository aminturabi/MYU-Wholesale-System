/* ==================== POS BILLING & INVOICE CREATION MODULE ==================== */
class BillingModule {
        constructor() {
          this.cartItems = [];
          this.bindEvents();
          if (typeof document !== 'undefined') {
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
              setTimeout(() => this.initView(), 50);
            } else {
              document.addEventListener('DOMContentLoaded', () => this.initView());
            }
          }
        }

        bindEvents() {
          const searchInput = document.getElementById('pos-product-search');
          const dropdown = document.getElementById('pos-search-results');

          if (searchInput) {
            searchInput.addEventListener('input', (e) => this.renderSearchResults(e.target.value.toLowerCase().trim()));
            searchInput.addEventListener('focus', (e) => {
              const q = e.target.value.toLowerCase().trim();
              if (q) this.renderSearchResults(q);
            });
            searchInput.addEventListener('keydown', (e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                const topResult = dropdown ? dropdown.querySelector('.search-result-item') : null;
                if (topResult) topResult.click();
              } else if (e.key === 'Escape') {
                if (dropdown) { dropdown.classList.remove('active'); dropdown.style.display = 'none'; }
              }
            });
            document.addEventListener('click', (e) => {
              if (dropdown && searchInput && !searchInput.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
                dropdown.style.display = 'none';
              }
            });
          }

          const custSelect = document.getElementById('pos-customer-select');
          if (custSelect) custSelect.addEventListener('change', () => this.updateCustomerBalanceDisplay());

          const paidInput = document.getElementById('pos-paid-input');
          if (paidInput) paidInput.addEventListener('input', () => this.calculateCartTotals());

          const saveBtn = document.getElementById('btn-complete-sale');
          if (saveBtn) saveBtn.addEventListener('click', () => this.completeSaleAndPrint());
        }

        initView() {
          try {
            this.bindEvents();
            const settings = (storage && typeof storage.getSettings === 'function') ? storage.getSettings() : {};
            const sales = (storage && typeof storage.getSales === 'function') ? storage.getSales() : [];
            const customers = (storage && typeof storage.getCustomers === 'function') ? storage.getCustomers() : [];

            const prefix = settings.invoicePrefix || 'MYU-INV-';
            const nextNum = prefix + String((sales || []).length + 1).padStart(6, '0');

            const invElem = document.getElementById('pos-invoice-num') || document.getElementById('bill-invoice-num');
            if (invElem) invElem.value = nextNum;

            const dtElem = document.getElementById('pos-datetime') || document.getElementById('bill-date');
            if (dtElem) dtElem.value = `${Utils.todayStr()} ${Utils.nowTimeStr()}`;

            const select = document.getElementById('pos-customer-select') || document.getElementById('bill-customer-select');
            if (select) {
              Utils.populateSelect(select, customers || [], 'id', c => `${c.name} ${c.shopName ? '(' + c.shopName + ')' : ''}`, '', '-- Walk-in / Select Customer --');
            }

            this.updateCustomerBalanceDisplay();
            this.calculateCartTotals();
          } catch (e) {
            console.error('Error in BillingModule.initView:', e);
          }
        }

        updateCustomerBalanceDisplay() {
          const custId = document.getElementById('pos-customer-select').value;
          const cust = storage.getCustomers().find(c => c.id === custId);
          const settings = storage.getSettings();
          const prevBalElem = document.getElementById('pos-prev-balance');

          if (prevBalElem) {
            prevBalElem.textContent = Utils.formatCurrency(cust ? cust.remainingBalance : 0, settings.currency);
          }
          this.calculateCartTotals();
        }

        handleSearchInput(query) {
          this.renderSearchResults((query || '').toLowerCase().trim());
        }

        renderSearchResults(query) {
          const dropdown = document.getElementById('pos-search-results');
          if (!dropdown) return;

          if (!query) {
            dropdown.classList.remove('active');
            dropdown.style.display = 'none';
            return;
          }

          const products = (storage && typeof storage.getProducts === 'function') ? storage.getProducts() : [];
          const filtered = products.filter(p => {
            const q = query.toLowerCase();
            return (p.name || '').toLowerCase().includes(q) ||
              (p.genericName || '').toLowerCase().includes(q) ||
              (p.itemNo || '').toLowerCase().includes(q) ||
              (p.batchNumber || '').toLowerCase().includes(q) ||
              (p.company || '').toLowerCase().includes(q) ||
              (p.brand || '').toLowerCase().includes(q) ||
              (p.category || '').toLowerCase().includes(q);
          });

          if (!filtered.length) {
            dropdown.innerHTML = `<div style="padding: 14px; text-align: center; color: var(--text-muted); font-size: 0.88rem; background: #ffffff;">No medicine found matching "${query}".</div>`;
            dropdown.classList.add('active');
            dropdown.style.display = 'block';
            return;
          }

          let html = '';
          filtered.slice(0, 12).forEach(p => {
            const isOut = p.availableQty <= 0;
            const isExpired = p.expiryDate && new Date(p.expiryDate) < new Date();
            const badgeText = isOut ? 'Out of Stock' : (isExpired ? 'EXPIRED' : `${p.availableQty} in stock`);

            html += `
            <div class="search-result-item" onmousedown="event.preventDefault(); billingModule.addProductToCart('${p.id}');" style="padding: 10px 14px; border-bottom: 1px solid #f1f5f9; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: #ffffff;">
              <div style="flex: 1;">
                <div style="font-weight: 700; color: var(--text-main); font-size: 0.92rem;">
                  ${p.name} <span style="font-size: 0.78rem; color: var(--primary); font-weight: 600;">(${p.itemNo})</span>
                </div>
                <div style="font-size: 0.76rem; color: var(--text-muted); margin-top: 2px;">
                  ${p.genericName ? p.genericName + ' | ' : ''}Company: ${p.company || 'N/A'} | Batch: ${p.batchNumber || '-'} | Exp: ${p.expiryDate || '-'}
                </div>
              </div>
              <div style="text-align: right; margin-left: 12px;">
                <div style="font-weight: 800; color: var(--primary); font-size: 0.95rem;">Rs. ${(p.salePrice || 0).toFixed(2)}</div>
                ${Utils.badge(badgeText)}
              </div>
            </div>
          `;
          });

          dropdown.innerHTML = html;
          dropdown.classList.add('active');
          dropdown.style.display = 'block';
        }

        showToast(msg, type = 'info', duration = 3000) {
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          if (appObj && typeof appObj.showToast === 'function') {
            appObj.showToast(msg, type, duration);
          }
        }

        addProductToCart(productId) {
          const searchInput = document.getElementById('pos-product-search');
          if (searchInput) searchInput.value = '';
          const dropdown = document.getElementById('pos-search-results');
          if (dropdown) { dropdown.classList.remove('active'); dropdown.style.display = 'none'; }

          const prod = storage.getProducts().find(p => p.id === productId);
          if (!prod) return;

          if (prod.expiryDate && new Date(prod.expiryDate) < new Date()) {
            this.showToast(`WARNING: ${prod.name} (Batch: ${prod.batchNumber}) HAS EXPIRED! Do not sell expired medicines.`, 'danger', 5000);
          }

          if (prod.availableQty <= 0) {
            this.showToast(`Cannot add ${prod.name}! Item is Out of Stock (0 available).`, 'danger');
            return;
          }

          const existingIdx = this.cartItems.findIndex(ci => ci.productId === prod.id);
          if (existingIdx !== -1) {
            const newQty = this.cartItems[existingIdx].quantity + 1;
            if (newQty > prod.availableQty) {
              this.showToast(`Insufficient stock! Only ${prod.availableQty} units available for ${prod.name}.`, 'warning');
              return;
            }
            this.cartItems[existingIdx].quantity = newQty;
            this.updateItemTotal(existingIdx);
          } else {
            const item = {
              productId: prod.id,
              code: prod.itemNo || prod.code || 'MED',
              itemNo: prod.itemNo || 'MED',
              name: prod.name,
              packSize: prod.packSize || prod.pSize || '10x10',
              batchNumber: prod.batchNumber || '-',
              expiryDate: prod.expiryDate || '-',
              maxStock: prod.availableQty,
              quantity: 1,
              bonus: 0,
              price: parseFloat(prod.salePrice) || 0,
              tp: parseFloat(prod.tp || prod.costPrice) || (parseFloat(prod.salePrice) * 0.85),
              discountPercent: parseFloat(prod.discount) || 0,
              extPercent: 0,
              taxPercent: 0,
              totalAmount: 0
            };
            this.cartItems.push(item);
            this.updateItemTotal(this.cartItems.length - 1);
          }

          this.renderCartTable();
          this.calculateCartTotals();
          this.showToast(`Added ${prod.name} to bill.`, 'success', 2000);
        }

        updateRowDom(index) {
          const tbody = document.getElementById('pos-cart-tbody');
          if (!tbody || !tbody.children[index]) return;
          const row = tbody.children[index];
          const item = this.cartItems[index];
          if (!item) return;

          if (row.cells[8]) row.cells[8].textContent = item.totalQty || item.quantity;
          if (row.cells[14]) row.cells[14].textContent = `Rs.${(item.netUnitPrice || item.price).toFixed(2)}`;
          if (row.cells[15]) row.cells[15].textContent = `Rs.${item.totalAmount.toFixed(2)}`;
        }

        updateCartItemQty(index, qtyStr) {
          const qty = parseInt(qtyStr) || 0;
          const item = this.cartItems[index];
          if (!item) return;

          if (qty > item.maxStock) {
            this.showToast(`Insufficient stock. Only ${item.maxStock} units are available for ${item.name}.`, 'warning', 3000);
            item.quantity = item.maxStock;
          } else {
            item.quantity = Math.max(1, qty);
          }

          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemBonus(index, bonusStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].bonus = Math.max(0, parseInt(bonusStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemPrice(index, priceStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].price = Math.max(0, parseFloat(priceStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemDisc(index, discStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].discountPercent = Math.max(0, parseFloat(discStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemExt(index, extStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].extPercent = Math.max(0, parseFloat(extStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemTax(index, taxStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].taxPercent = Math.max(0, parseFloat(taxStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateItemTotal(index) {
          const item = this.cartItems[index];
          if (!item) return;
          const calc = Utils.calcWholesaleLine(
            item.quantity,
            item.price,
            item.bonus,
            item.discountPercent,
            item.extPercent,
            item.taxPercent,
            item.tp
          );
          item.totalQty = calc.totalQty;
          item.disAmount = calc.disAmount;
          item.extAmount = calc.extAmount;
          item.taxAmount = calc.taxAmount;
          item.taxableBase = calc.taxableBase;
          item.netUnitPrice = calc.netUnitPrice;
          item.totalAmount = calc.lineAmount;
          item.profit = calc.profit;
        }

        removeCartItem(index) {
          this.cartItems.splice(index, 1);
          this.renderCartTable();
          this.calculateCartTotals();
        }

        renderCartTable() {
          const tbody = document.getElementById('pos-cart-tbody');
          if (!tbody) return;

          if (!this.cartItems.length) {
            Utils.emptyTable(tbody, 17, '<i class="fa-solid fa-basket-shopping" style="font-size: 2rem; color: #cbd5e1; margin-bottom: 8px; display: block;"></i> No items added to bill yet. Search & add medicines above.');
            return;
          }

          let html = '';
          this.cartItems.forEach((item, idx) => {
            html += `
            <tr style="font-size: 0.82rem;">
              <td style="text-align: center; color: var(--text-muted); font-weight: 700;">${idx + 1}</td>
              <td><span style="font-weight: 700; color: var(--primary);">${item.code || item.itemNo}</span></td>
              <td>
                <div style="font-weight: 700; color: var(--text-main); line-height: 1.2;">${item.name}</div>
              </td>
              <td><span style="color: #475569; font-weight: 600;">${item.packSize || '-'}</span></td>
              <td>
                <div style="font-weight: 600; color: #334155;">${item.batchNumber || '-'}</div>
                <div style="font-size: 0.72rem; color: var(--text-muted);">${item.expiryDate || ''}</div>
              </td>
              <div style="text-align: right; margin-left: 12px;">
                <div style="font-weight: 800; color: var(--primary); font-size: 0.95rem;">Rs. ${(p.salePrice || 0).toFixed(2)}</div>
                ${Utils.badge(badgeText)}
              </div>
            </div>
          `;
          });

          dropdown.innerHTML = html;
          dropdown.classList.add('active');
          dropdown.style.display = 'block';
        }

        showToast(msg, type = 'info', duration = 3000) {
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          if (appObj && typeof appObj.showToast === 'function') {
            appObj.showToast(msg, type, duration);
          }
        }

        addProductToCart(productId) {
          const searchInput = document.getElementById('pos-product-search');
          if (searchInput) searchInput.value = '';
          const dropdown = document.getElementById('pos-search-results');
          if (dropdown) { dropdown.classList.remove('active'); dropdown.style.display = 'none'; }

          const prod = storage.getProducts().find(p => p.id === productId);
          if (!prod) return;

          if (prod.expiryDate && new Date(prod.expiryDate) < new Date()) {
            this.showToast(`WARNING: ${prod.name} (Batch: ${prod.batchNumber}) HAS EXPIRED! Do not sell expired medicines.`, 'danger', 5000);
          }

          if (prod.availableQty <= 0) {
            this.showToast(`Cannot add ${prod.name}! Item is Out of Stock (0 available).`, 'danger');
            return;
          }

          const existingIdx = this.cartItems.findIndex(ci => ci.productId === prod.id);
          if (existingIdx !== -1) {
            const newQty = this.cartItems[existingIdx].quantity + 1;
            if (newQty > prod.availableQty) {
              this.showToast(`Insufficient stock! Only ${prod.availableQty} units available for ${prod.name}.`, 'warning');
              return;
            }
            this.cartItems[existingIdx].quantity = newQty;
            this.updateItemTotal(existingIdx);
          } else {
            const item = {
              productId: prod.id,
              code: prod.itemNo || prod.code || 'MED',
              itemNo: prod.itemNo || 'MED',
              name: prod.name,
              packSize: prod.packSize || prod.pSize || '10x10',
              batchNumber: prod.batchNumber || '-',
              expiryDate: prod.expiryDate || '-',
              maxStock: prod.availableQty,
              quantity: 1,
              bonus: 0,
              price: parseFloat(prod.salePrice) || 0,
              tp: parseFloat(prod.tp || prod.costPrice) || (parseFloat(prod.salePrice) * 0.85),
              discountPercent: parseFloat(prod.discount) || 0,
              extPercent: 0,
              taxPercent: 0,
              totalAmount: 0
            };
            this.cartItems.push(item);
            this.updateItemTotal(this.cartItems.length - 1);
          }

          this.renderCartTable();
          this.calculateCartTotals();
          this.showToast(`Added ${prod.name} to bill.`, 'success', 2000);
        }

        updateRowDom(index) {
          const tbody = document.getElementById('pos-cart-tbody');
          if (!tbody || !tbody.children[index]) return;
          const row = tbody.children[index];
          const item = this.cartItems[index];
          if (!item) return;

          if (row.cells[8]) row.cells[8].textContent = item.totalQty || item.quantity;
          if (row.cells[14]) row.cells[14].textContent = `Rs.${(item.netUnitPrice || item.price).toFixed(2)}`;
          if (row.cells[15]) row.cells[15].textContent = `Rs.${item.totalAmount.toFixed(2)}`;
        }

        updateCartItemQty(index, qtyStr) {
          const qty = parseInt(qtyStr) || 0;
          const item = this.cartItems[index];
          if (!item) return;

          if (qty > item.maxStock) {
            this.showToast(`Insufficient stock. Only ${item.maxStock} units are available for ${item.name}.`, 'warning', 3000);
            item.quantity = item.maxStock;
          } else {
            item.quantity = Math.max(1, qty);
          }

          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemBonus(index, bonusStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].bonus = Math.max(0, parseInt(bonusStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemPrice(index, priceStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].price = Math.max(0, parseFloat(priceStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemDisc(index, discStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].discountPercent = Math.max(0, parseFloat(discStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemExt(index, extStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].extPercent = Math.max(0, parseFloat(extStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateCartItemTax(index, taxStr) {
          if (!this.cartItems[index]) return;
          this.cartItems[index].taxPercent = Math.max(0, parseFloat(taxStr) || 0);
          this.updateItemTotal(index);
          this.updateRowDom(index);
          this.calculateCartTotals();
        }

        updateItemTotal(index) {
          const item = this.cartItems[index];
          if (!item) return;
          const calc = Utils.calcWholesaleLine(
            item.quantity,
            item.price,
            item.bonus,
            item.discountPercent,
            item.extPercent,
            item.taxPercent,
            item.tp
          );
          item.totalQty = calc.totalQty;
          item.disAmount = calc.disAmount;
          item.extAmount = calc.extAmount;
          item.taxAmount = calc.taxAmount;
          item.taxableBase = calc.taxableBase;
          item.netUnitPrice = calc.netUnitPrice;
          item.totalAmount = calc.lineAmount;
          item.profit = calc.profit;
        }

        removeCartItem(index) {
          this.cartItems.splice(index, 1);
          this.renderCartTable();
          this.calculateCartTotals();
        }

        renderCartTable() {
          const tbody = document.getElementById('pos-cart-tbody');
          if (!tbody) return;

          if (!this.cartItems.length) {
            Utils.emptyTable(tbody, 17, '<i class="fa-solid fa-basket-shopping" style="font-size: 2rem; color: #cbd5e1; margin-bottom: 8px; display: block;"></i> No items added to bill yet. Search & add medicines above.');
            return;
          }

          let html = '';
          this.cartItems.forEach((item, idx) => {
            html += `
            <tr style="font-size: 0.82rem;">
              <td style="text-align: center; color: var(--text-muted); font-weight: 700;">${idx + 1}</td>
              <td><span style="font-weight: 700; color: var(--primary);">${item.code || item.itemNo}</span></td>
              <td>
                <div style="font-weight: 700; color: var(--text-main); line-height: 1.2;">${item.name}</div>
              </td>
              <td><span style="color: #475569; font-weight: 600;">${item.packSize || '-'}</span></td>
              <td>
                <div style="font-weight: 600; color: #334155;">${item.batchNumber || '-'}</div>
                <div style="font-size: 0.72rem; color: var(--text-muted);">${item.expiryDate || ''}</div>
              </td>
              <td style="text-align: center;"><span class="badge-status badge-in-stock" style="font-size: 0.75rem; padding: 2px 5px;">${item.maxStock}</span></td>
              <td><input type="number" class="form-control-myu pos-cart-input" value="${item.quantity}" min="1" max="${item.maxStock}" oninput="billingModule.updateCartItemQty(${idx}, this.value)" onchange="billingModule.updateCartItemQty(${idx}, this.value)" style="width: 60px; padding: 4px;"></td>
              <td><input type="number" class="form-control-myu pos-cart-input" value="${item.bonus || 0}" min="0" oninput="billingModule.updateCartItemBonus(${idx}, this.value)" onchange="billingModule.updateCartItemBonus(${idx}, this.value)" style="width: 55px; padding: 4px;"></td>
              <td style="text-align: center; font-weight: 800; color: #0f172a;">${item.totalQty || item.quantity}</td>
              <td style="text-align: right; color: #64748b; font-weight: 600;">Rs.${item.tp.toFixed(2)}</td>
              <td><input type="number" step="0.01" class="form-control-myu pos-cart-input" value="${item.price}" oninput="billingModule.updateCartItemPrice(${idx}, this.value)" onchange="billingModule.updateCartItemPrice(${idx}, this.value)" style="width: 75px; padding: 4px;"></td>
              <td><input type="number" step="0.1" class="form-control-myu pos-cart-input" value="${item.discountPercent || 0}" oninput="billingModule.updateCartItemDisc(${idx}, this.value)" onchange="billingModule.updateCartItemDisc(${idx}, this.value)" style="width: 55px; padding: 4px;"></td>
              <td><input type="number" step="0.1" class="form-control-myu pos-cart-input" value="${item.extPercent || 0}" oninput="billingModule.updateCartItemExt(${idx}, this.value)" onchange="billingModule.updateCartItemExt(${idx}, this.value)" style="width: 55px; padding: 4px;"></td>
              <td><input type="number" step="0.1" class="form-control-myu pos-cart-input" value="${item.taxPercent || 0}" oninput="billingModule.updateCartItemTax(${idx}, this.value)" onchange="billingModule.updateCartItemTax(${idx}, this.value)" style="width: 55px; padding: 4px;"></td>
              <td style="text-align: right; font-weight: 700; color: #0f172a;">Rs.${(item.netUnitPrice || item.price).toFixed(2)}</td>
              <td style="text-align: right; font-weight: 800; color: var(--primary);">Rs.${item.totalAmount.toFixed(2)}</td>
              <td style="text-align: center;"><button type="button" class="btn-danger-myu btn-sm-myu" onclick="billingModule.removeCartItem(${idx})" style="padding: 3px 6px; font-size: 0.78rem;" title="Remove Item"><i class="fa-solid fa-xmark"></i></button></td>
            </tr>`;
          });
          tbody.innerHTML = html;
        }

        calculateCartTotals() {
          let grossTotal = 0, totalDiscount = 0, totalTax = 0;
          this.cartItems.forEach(item => {
            const calc = Utils.calcWholesaleLine(
              item.quantity, item.price, item.bonus,
              item.discountPercent, item.extPercent, item.taxPercent, item.tp
            );
            grossTotal += calc.grossSubtotal;
            totalDiscount += (calc.disAmount + calc.extAmount);
            totalTax += calc.taxAmount;
          });

          const netAmount = Math.max(0, grossTotal - totalDiscount + totalTax);
          const paidInput = document.getElementById('pos-paid-input');
          let paid = parseFloat(paidInput ? paidInput.value : 0) || 0;
          const payMethodElem = document.getElementById('pos-payment-method');
          const payMethod = payMethodElem ? payMethodElem.value : 'Cash';

          if (payMethod === 'Cash' && (!paidInput || paidInput.value === '0')) {
            paid = netAmount;
            if (paidInput) paidInput.value = netAmount;
          }

          const balanceDue = Math.max(0, netAmount - paid);
          const settings = storage.getSettings();

          const grossElem = document.getElementById('pos-gross-total');
          if (grossElem) grossElem.textContent = Utils.formatCurrency(grossTotal, settings.currency);
          const discElem = document.getElementById('pos-total-discount');
          if (discElem) discElem.textContent = Utils.formatCurrency(totalDiscount, settings.currency);
          const netElem = document.getElementById('pos-net-amount');
          if (netElem) netElem.textContent = Utils.formatCurrency(netAmount, settings.currency);
          const balElem = document.getElementById('pos-balance-due');
          if (balElem) balElem.textContent = Utils.formatCurrency(balanceDue, settings.currency);
        }

        resetBill() {
          this.cartItems = [];
          const searchElem = document.getElementById('pos-product-search');
          if (searchElem) searchElem.value = '';
          const paidElem = document.getElementById('pos-paid-input');
          if (paidElem) paidElem.value = 0;
          this.renderCartTable();
          this.calculateCartTotals();
          this.showToast('Cleared current bill items.', 'info');
        }

        completeSaleAndPrint() {
          const list = (this.cartItems && this.cartItems.length) ? this.cartItems : [];
          if (!list.length) {
            this.showToast('Cannot complete sale with an empty bill! Add medicines first.', 'warning');
            return;
          }

          const custSelect = document.getElementById('pos-customer-select') || document.getElementById('bill-customer-select');
          const custId = custSelect ? custSelect.value : '';
          const customers = storage.getCustomers ? storage.getCustomers() : [];
          const cust = customers.find(c => c.id === custId) || { id: 'CUST-104', name: 'Walk-in Customer', shopName: 'Retail', phone: '', address: 'Mardan' };

          let grossTotal = 0, totalDiscount = 0, totalTax = 0;
          const items = list.map(ci => {
            const qty = parseInt(ci.quantity) || 1;
            const bns = parseInt(ci.bonus) || 0;
            const price = parseFloat(ci.price || ci.unitPrice || ci.salePrice) || 0;
            const tp = parseFloat(ci.tp || ci.costPrice) || (price * 0.85);
            const discPercent = parseFloat(ci.discountPercent) || 0;
            const extPercent = parseFloat(ci.extPercent) || 0;
            const taxPercent = parseFloat(ci.taxPercent) || 0;

            const calc = Utils.calcWholesaleLine(qty, price, bns, discPercent, extPercent, taxPercent, tp);
            grossTotal += calc.grossSubtotal;
            totalDiscount += (calc.disAmount + calc.extAmount);
            totalTax += calc.taxAmount;

            return {
              productId: ci.productId || ci.id,
              itemNo: ci.itemNo || ci.code || 'MED',
              name: ci.name,
              packSize: ci.packSize || '10x10',
              batchNumber: ci.batchNumber || '',
              expiryDate: ci.expiryDate || '',
              quantity: qty,
              bonus: bns,
              totalQty: calc.totalQty,
              price: price,
              tp: tp,
              discountPercent: discPercent,
              discountAmount: calc.disAmount,
              extPercent: extPercent,
              extAmount: calc.extAmount,
              taxPercent: taxPercent,
              taxAmount: calc.taxAmount,
              netUnitPrice: calc.netUnitPrice,
              totalAmount: calc.lineAmount,
              itemProfit: calc.profit
            };
          });

          const netAmount = Math.max(0, grossTotal - totalDiscount + totalTax);
          const paidInput = document.getElementById('pos-paid-input') || document.getElementById('bill-paid-amount');
          let paid = parseFloat(paidInput ? paidInput.value : 0) || 0;
          const payMethodElem = document.getElementById('pos-payment-method') || document.getElementById('bill-payment-method');
          const payMethod = payMethodElem ? payMethodElem.value : 'Cash';

          if (payMethod === 'Cash' && paid <= 0) {
            paid = netAmount;
          }

          const remaining = Math.max(0, netAmount - paid);
          const invNumElem = document.getElementById('pos-invoice-num') || document.getElementById('bill-invoice-num');
          const invNum = invNumElem ? invNumElem.value : ("MYU-INV-" + String(storage.getSales().length + 1).padStart(6, '0'));

          const savedSale = storage.addSale({
            invoiceNumber: invNum,
            date: Utils.todayStr(),
            time: Utils.nowTimeStr(),
            customerId: cust.id,
            customerName: cust.name,
            customerShop: cust.shopName || '',
            customerPhone: cust.phone || '',
            customerAddress: cust.address || '',
            paymentMethod: payMethod,
            items: items,
            grossTotal: grossTotal,
            totalDiscount: totalDiscount,
            tax: totalTax,
            previousBalance: cust.remainingBalance || 0,
            netAmount: netAmount,
            paidAmount: paid,
            remainingBalance: remaining
          });

          this.showToast('Sale Invoice created & inventory updated!', 'success');
          this.triggerPrintInvoice(savedSale);
          this.resetBill();
        }

        triggerPrintInvoice(sale) {
          if (!sale) return;
          const container = document.getElementById('printable-invoice');
          if (!container) return;
          const settings = storage.getSettings();

          let html = '';
          if (window.salesModule && typeof window.salesModule.buildInvoiceTemplate === 'function') {
            html = window.salesModule.buildInvoiceTemplate(sale, settings);
          } else if (typeof SalesModule !== 'undefined' && SalesModule.prototype.buildInvoiceTemplate) {
            html = SalesModule.prototype.buildInvoiceTemplate(sale, settings);
          }

          if (html) {
            container.innerHTML = html;
            setTimeout(() => {
              window.print();
            }, 250);
          }
        }
}

if (typeof global !== 'undefined') {
  global.BillingModule = BillingModule;
}
if (typeof window !== 'undefined') {
  window.BillingModule = BillingModule;
  window.billingModule = window.billingModule || new BillingModule();
}
