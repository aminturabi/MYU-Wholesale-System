/* ==================== PRODUCTS & INVENTORY MODULE ==================== */
class ProductsModule {
        constructor() { this.bindEvents(); }

        bindEvents() {
          const search = document.getElementById('prod-search-input');
          const cat = document.getElementById('prod-category-filter');
          if (search) search.addEventListener('input', () => this.renderProducts());
          if (cat) cat.addEventListener('change', () => this.renderProducts());

          const invSearch = document.getElementById('inv-search-input');
          const invStatus = document.getElementById('inv-status-filter');
          if (invSearch) invSearch.addEventListener('input', () => this.renderInventory());
          if (invStatus) invStatus.addEventListener('change', () => this.renderInventory());

          const expFilter = document.getElementById('expiry-filter-select');
          if (expFilter) expFilter.addEventListener('change', () => this.renderExpiry());

          const prodForm = document.getElementById('product-form');
          if (prodForm) prodForm.addEventListener('submit', (e) => { e.preventDefault(); this.saveProductForm(); });
        }

        renderProducts() {
          const tbody = document.getElementById('products-tbody');
          if (!tbody) return;

          const products = storage.getProducts();
          const settings = storage.getSettings();

          const query = (document.getElementById('prod-search-input').value || '').toLowerCase().trim();
          const category = document.getElementById('prod-category-filter').value || '';

          const filtered = products.filter(p => {
            const matchQuery = !query || p.name.toLowerCase().includes(query) || (p.genericName || '').toLowerCase().includes(query) || p.itemNo.toLowerCase().includes(query) || (p.company || '').toLowerCase().includes(query) || (p.batchNumber || '').toLowerCase().includes(query);
            return matchQuery && (!category || p.category === category);
          });

          if (!filtered.length) { Utils.emptyTable(tbody, 11, 'No products found matching search criteria.'); return; }

          let html = '';
          filtered.forEach(p => {
            const isOut = p.availableQty <= 0;
            const isLow = !isOut && p.availableQty <= (p.minStockLevel || settings.minStockAlert);
            const statusText = isOut ? 'Out of Stock' : (isLow ? 'Low Stock' : 'In Stock');

            html += `
            <tr>
              <td><span style="font-weight: 700; color: var(--primary);">${p.itemNo}</span></td>
              <td><div style="font-weight: 700;">${p.name}</div><div style="font-size: 0.75rem; color: var(--text-muted);">${p.genericName || 'N/A'}</div></td>
              <td>${p.company || '-'}</td>
              <td><span style="background: #f1f5f9; padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">${p.category}</span></td>
              <td><div style="font-size: 0.8rem; font-weight: 600;">${p.batchNumber || '-'}</div><div style="font-size: 0.72rem; color: var(--text-muted);">${p.expiryDate || 'No Expiry'}</div></td>
              <td style="font-weight: 600;">${Utils.formatCurrency(p.tp, settings.currency)}</td>
              <td style="font-weight: 700; color: var(--primary);">${Utils.formatCurrency(p.salePrice, settings.currency)}</td>
              <td><span style="font-weight: 800; font-size: 0.95rem;">${p.availableQty}</span><span style="font-size: 0.7rem; color: var(--text-muted);"> (Min: ${p.minStockLevel || 10})</span></td>
              <td>${p.rackNumber || '-'}</td>
              <td>${Utils.badge(statusText)}</td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <button class="btn-secondary-myu btn-sm-myu" onclick="productsModule.openEditModal('${p.id}')" title="Edit Product"><i class="fa-solid fa-pen-to-square"></i></button>
                  <button class="btn-danger-myu btn-sm-myu" onclick="productsModule.deleteProduct('${p.id}')" title="Delete Product"><i class="fa-solid fa-trash"></i></button>
                </div>
              </td>
            </tr>
          `;
          });
          tbody.innerHTML = html;
        }

        populateCompanyDropdown(selectedCompany = '') {
          const select = document.getElementById('pm-company');
          if (!select) return;
          const companies = storage.getCompanies();
          Utils.populateSelect(select, companies, 'name', 'name', selectedCompany, '-- Select Company / Supplier --');
        }

        openAddModal() {
          document.getElementById('prod-modal-title').textContent = 'Add New Product';
          document.getElementById('product-form').reset();
          document.getElementById('prod-edit-id').value = '';
          this.populateCompanyDropdown();
          document.getElementById('pm-item-no').value = 'MED-' + (1000 + storage.getProducts().length + 1);
          app.openModal('product-modal');
        }

        openEditModal(id) {
          const p = storage.getProducts().find(prod => prod.id === id);
          if (!p) return;
          document.getElementById('prod-modal-title').textContent = 'Edit Product Details';
          document.getElementById('prod-edit-id').value = p.id;
          document.getElementById('pm-item-no').value = p.itemNo;
          document.getElementById('pm-name').value = p.name;
          document.getElementById('pm-generic').value = p.genericName || '';
          this.populateCompanyDropdown(p.company || '');
          document.getElementById('pm-category').value = p.category || 'Medicines';
          document.getElementById('pm-batch').value = p.batchNumber || '';
          document.getElementById('pm-expiry').value = p.expiryDate || '';
          document.getElementById('pm-tp').value = p.tp;
          document.getElementById('pm-sale-price').value = p.salePrice;
          document.getElementById('pm-retail-price').value = p.retailPrice || p.salePrice;
          document.getElementById('pm-purchased-qty').value = p.purchasedQty || 0;
          document.getElementById('pm-available-qty').value = p.availableQty || 0;
          document.getElementById('pm-min-stock').value = p.minStockLevel || 10;
          document.getElementById('pm-rack').value = p.rackNumber || '';
          document.getElementById('pm-notes').value = p.notes || '';
          app.openModal('product-modal');
        }

        saveProductForm() {
          const editId = document.getElementById('prod-edit-id').value;
          const data = {
            itemNo: document.getElementById('pm-item-no').value, name: document.getElementById('pm-name').value, genericName: document.getElementById('pm-generic').value,
            company: document.getElementById('pm-company').value, category: document.getElementById('pm-category').value, batchNumber: document.getElementById('pm-batch').value,
            expiryDate: document.getElementById('pm-expiry').value, tp: parseFloat(document.getElementById('pm-tp').value) || 0, salePrice: parseFloat(document.getElementById('pm-sale-price').value) || 0,
            retailPrice: parseFloat(document.getElementById('pm-retail-price').value) || 0, purchasedQty: parseInt(document.getElementById('pm-purchased-qty').value) || 0,
            availableQty: parseInt(document.getElementById('pm-available-qty').value) || 0, minStockLevel: parseInt(document.getElementById('pm-min-stock').value) || 10,
            rackNumber: document.getElementById('pm-rack').value, notes: document.getElementById('pm-notes').value
          };

          let newProd = null;
          if (editId) {
            storage.updateProduct(editId, data);
            app.showToast('Product details updated successfully!', 'success');
          } else {
            newProd = storage.addProduct(data);
            app.showToast('New product added to inventory!', 'success');
          }
          app.closeModal('product-modal');

          if (app.currentView === 'purchases-view' && newProd) {
            purchasesModule.onNewProductAdded(newProd);
          } else {
            app.refreshCurrentView();
          }
        }

        deleteProduct(id) {
          app.confirmDelete('Are you sure you want to remove this product from inventory?', () => {
            storage.deleteProduct(id); app.showToast('Product deleted.', 'info'); app.refreshCurrentView();
          });
        }

        renderInventory() {
          const tbody = document.getElementById('inventory-tbody');
          if (!tbody) return;

          const products = storage.getProducts();
          const settings = storage.getSettings();

          const query = (document.getElementById('inv-search-input').value || '').toLowerCase().trim();
          const statusFilter = document.getElementById('inv-status-filter').value || '';

          const filtered = products.filter(p => {
            const matchQuery = !query || p.name.toLowerCase().includes(query) || p.itemNo.toLowerCase().includes(query) || (p.company || '').toLowerCase().includes(query) || (p.batchNumber || '').toLowerCase().includes(query);
            const isOut = p.availableQty <= 0;
            const isLow = !isOut && p.availableQty <= (p.minStockLevel || settings.minStockAlert);
            const status = isOut ? 'Out of Stock' : (isLow ? 'Low Stock' : 'In Stock');
            return matchQuery && (!statusFilter || status === statusFilter);
          });

          if (!filtered.length) { Utils.emptyTable(tbody, 11, 'No inventory records match filter.'); return; }

          let html = '';
          filtered.forEach(p => {
            const isOut = p.availableQty <= 0;
            const isLow = !isOut && p.availableQty <= (p.minStockLevel || settings.minStockAlert);
            const statusText = isOut ? 'Out of Stock' : (isLow ? 'Low Stock' : 'In Stock');

            html += `
            <tr>
              <td><span style="font-weight: 700; color: var(--primary);">${p.itemNo}</span></td>
              <td><div style="font-weight: 700;">${p.name}</div><div style="font-size: 0.72rem; color: var(--text-muted);">${p.rackNumber ? 'Rack: ' + p.rackNumber : ''}</div></td>
              <td>${p.company || '-'}</td>
              <td>${p.batchNumber || '-'}</td>
              <td>${p.expiryDate || '-'}</td>
              <td>${p.purchasedQty || 0}</td>
              <td>${p.bonusQty || 0}</td>
              <td><span style="font-weight: 800; font-size: 1rem; color: ${isOut ? '#ef4444' : 'var(--text-main)'};">${p.availableQty}</span></td>
              <td>${Utils.formatCurrency(p.tp, settings.currency)}</td>
              <td style="font-weight: 700; color: var(--primary);">${Utils.formatCurrency(p.salePrice, settings.currency)}</td>
              <td>${Utils.badge(statusText)}</td>
            </tr>
          `;
          });
          tbody.innerHTML = html;
        }

        renderExpiry() {
          const tbody = document.getElementById('expiry-tbody');
          if (!tbody) return;

          const expiryStatus = storage.getExpiryStatus();
          document.getElementById('exp-count-expired').textContent = `${expiryStatus.expired.length} Items`;
          document.getElementById('exp-count-30').textContent = `${expiryStatus.within30.length} Items`;
          document.getElementById('exp-count-60').textContent = `${expiryStatus.within60.length} Items`;
          document.getElementById('exp-count-90').textContent = `${expiryStatus.within90.length} Items`;

          const filterVal = document.getElementById('expiry-filter-select').value || 'all';
          let list = filterVal === 'all' ? [...expiryStatus.expired, ...expiryStatus.within30, ...expiryStatus.within60, ...expiryStatus.within90] : (expiryStatus[filterVal] || []);

          if (!list.length) { Utils.emptyTable(tbody, 8, '<i class="fa-solid fa-circle-check" style="color: #10b981;"></i> No products found for selected expiry alert.'); return; }

          let html = '';
          list.forEach(p => {
            const isExpired = p.daysRemaining < 0;
            const statusText = isExpired ? 'EXPIRED' : `Expires in ${p.daysRemaining} Days`;
            html += `
            <tr>
              <td><span style="font-weight: 700; color: var(--primary);">${p.itemNo}</span></td>
              <td><div style="font-weight: 700;">${p.name}</div></td>
              <td><span style="font-weight: 600;">${p.batchNumber || '-'}</span></td>
              <td>${p.company || '-'}</td>
              <td><span style="font-weight: 700;">${p.availableQty}</span></td>
              <td style="font-weight: 700;">${p.expiryDate}</td>
              <td>${isExpired ? 'Expired' : p.daysRemaining + ' days'}</td>
              <td>${Utils.badge(statusText, isExpired ? 'badge-expired' : '')}</td>
            </tr>
          `;
          });
          tbody.innerHTML = html;
        }
      }

      var productsModule = window.productsModule || new ProductsModule();


      /* ==================== PURCHASES & SUPPLIER MODULE ==================== */

if (typeof global !== 'undefined') {
  global.ProductsModule = ProductsModule;
}
if (typeof window !== 'undefined') {
  window.ProductsModule = ProductsModule;
  window.productsModule = window.productsModule || new ProductsModule();
}
