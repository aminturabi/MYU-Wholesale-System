/* ==================== REUSABLE UTILITIES & HELPERS ==================== */
var app = typeof window !== 'undefined' && window.app ? window.app : null;
const MYU_OFFICIAL_LOGO_B64 = "myu-logo.png";
if (typeof window !== 'undefined') window.MYU_OFFICIAL_LOGO_B64 = MYU_OFFICIAL_LOGO_B64;
if (typeof global !== 'undefined') global.MYU_OFFICIAL_LOGO_B64 = MYU_OFFICIAL_LOGO_B64;

const Utils = {
        formatCurrency: (amount, currency = 'Rs.') => {
          const val = parseFloat(amount) || 0;
          return `${currency} ${val.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        },

        formatDate: (dateStr) => {
          if (!dateStr) return '-';
          return dateStr;
        },

        todayStr: (offsetDays = 0) => {
          const d = new Date();
          d.setDate(d.getDate() + offsetDays);
          return d.toISOString().split('T')[0];
        },

        nowTimeStr: () => {
          return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        },

        whatsappLink: (phone) => {
          if (!phone) return '';
          const clean = phone.replace(/[^0-9]/g, '');
          return clean ? `https://wa.me/${clean}` : '';
        },

        badge: (statusText, customClass = '') => {
          let badgeClass = 'badge-in-stock';
          if (['Out of Stock', 'EXPIRED', 'Unpaid'].includes(statusText)) badgeClass = 'badge-out-stock';
          else if (['Low Stock', 'Partially Paid'].includes(statusText)) badgeClass = 'badge-low-stock';
          else if (['Paid', 'In Stock'].includes(statusText)) badgeClass = 'badge-paid';

          return `<span class="badge-status ${customClass || badgeClass}">${statusText}</span>`;
        },

        calcLineTotal: (qty, price, discountPercent = 0) => {
          const q = parseInt(qty) || 0;
          const p = parseFloat(price) || 0;
          const d = parseFloat(discountPercent) || 0;
          const gross = q * p;
          return Math.max(0, gross - (gross * d) / 100);
        },

        calcWholesaleLine: (qty, price, bonus = 0, disPercent = 0, extPercent = 0, taxPercent = 0, tp = 0) => {
          const q = parseInt(qty) || 0;
          const bns = parseInt(bonus) || 0;
          const totalQty = q + bns;
          const p = parseFloat(price) || 0;
          const tradePrice = parseFloat(tp) || 0;
          const dis = parseFloat(disPercent) || 0;
          const ext = parseFloat(extPercent) || 0;
          const tax = parseFloat(taxPercent) || 0;

          const gross = q * p;
          const disAmount = (gross * dis) / 100;
          const afterDis = gross - disAmount;
          const extAmount = (afterDis * ext) / 100;
          const taxableBase = afterDis - extAmount;
          const taxAmount = (taxableBase * tax) / 100;
          const lineAmount = Math.max(0, taxableBase + taxAmount);
          const netUnitPrice = q > 0 ? (lineAmount / q) : p;
          const lineCost = q * tradePrice;
          const profit = lineAmount - lineCost;

          return {
            qty: q,
            bonus: bns,
            totalQty,
            price: p,
            tp: tradePrice,
            disPercent: dis,
            disAmount,
            extPercent: ext,
            extAmount,
            taxPercent: tax,
            taxAmount,
            grossSubtotal: gross,
            taxableBase,
            lineAmount,
            netUnitPrice,
            profit
          };
        },

        emptyTable: (tbody, colSpan, message) => {
          if (tbody) {
            tbody.innerHTML = `<tr><td colspan="${colSpan}" style="text-align: center; padding: 30px; color: var(--text-muted);">${message}</td></tr>`;
          }
        },

        populateSelect: (selectElem, items, valueKey, labelFn, selectedVal = '', defaultLabel = '-- Select --') => {
          if (!selectElem) return;
          let html = `<option value="">${defaultLabel}</option>`;
          (items || []).forEach(item => {
            if (!item) return;
            const val = item[valueKey] || item.id || item.invoiceNumber || '';
            const label = typeof labelFn === 'function' ? labelFn(item) : (item[labelFn] || val);
            const sel = val === selectedVal ? 'selected' : '';
            html += `<option value="${val}" ${sel}>${label}</option>`;
          });
          selectElem.innerHTML = html;
        },

        numberToWords: (num) => {
          if (!num || isNaN(num)) return "Zero Rupees";
          const n = Math.floor(Math.abs(num));
          if (n === 0) return "Zero Rupees";
          const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
            'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
          const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
          function inWords(amount) {
            if (amount < 20) return a[amount];
            if (amount < 100) return b[Math.floor(amount / 10)] + (amount % 10 ? ' ' + a[amount % 10] : '');
            if (amount < 1000) return a[Math.floor(amount / 100)] + ' Hundred' + (amount % 100 ? ' ' + inWords(amount % 100) : '');
            if (amount < 100000) return inWords(Math.floor(amount / 1000)) + ' Thousand' + (amount % 1000 ? ' ' + inWords(amount % 1000) : '');
            if (amount < 10000000) return inWords(Math.floor(amount / 100000)) + ' Lakh' + (amount % 100000 ? ' ' + inWords(amount % 100000) : '');
            return inWords(Math.floor(amount / 10000000)) + ' Crore' + (amount % 10000000 ? ' ' + inWords(amount % 10000000) : '');
          }
          return inWords(n) + " Rupees";
        }
      };
window.Utils = Utils;


      /* ==================== DATA STORAGE MANAGER ==================== */