/* ==================== STORAGE & DATABASE ENGINE ==================== */
const STORAGE_KEYS = {
        SETTINGS: 'myu_settings_v1',
        PRODUCTS: 'myu_products_v1',
        COMPANIES: 'myu_companies_v1',
        CUSTOMERS: 'myu_customers_v1',
        PURCHASES: 'myu_purchases_v1',
        SALES: 'myu_sales_v1',
        SUPPLIER_PAYMENTS: 'myu_supplier_payments_v1',
        CUSTOMER_PAYMENTS: 'myu_customer_payments_v1',
        EXPENSES: 'myu_expenses_v1',
        INCOMES: 'myu_incomes_v1',
        RETURNS: 'myu_returns_v1'
      };

      const DEFAULT_SETTINGS = {
        shopName: "MYU Medicine and Surgical Wholesale",
        address: "Jail Road, Mardan",
        phone: "03445094631",
        whatsapp: "923445094631",
        invoicePrefix: "MYU-INV-",
        purchasePrefix: "MYU-PUR-",
        currency: "Rs.",
        minStockAlert: 15,
        invoiceFooter: "Thank you for your business. Purchased medicines can be replaced within 7 days if seals are intact.",
        defaultDiscount: 0
      };

      const INITIAL_COMPANIES = [
        { id: "COMP-101", name: "GSK Pakistan Ltd", contactPerson: "Tariq Khan", phone: "03001234567", whatsapp: "923001234567", address: "Industrial Estate, Peshawar", email: "tariq.khan@gsk.com", openingBalance: 0, totalPurchases: 185000, totalPayments: 150000, remainingPayable: 35000, notes: "Primary distributor for Augmentin and Panadol" },
        { id: "COMP-102", name: "Getz Pharma", contactPerson: "Kamran Shah", phone: "03139876543", whatsapp: "923139876543", address: "Hayatabad Industrial Area, Peshawar", email: "info@getzpharma.com", openingBalance: 0, totalPurchases: 144000, totalPayments: 120000, remainingPayable: 24000, notes: "Risek and Osnate-D suppliers" },
        { id: "COMP-103", name: "Searle Company Ltd", contactPerson: "Bilal Ahmad", phone: "03335554433", whatsapp: "923335554433", address: "Nowshera Road, Mardan", email: "bilal@searle.com", openingBalance: 0, totalPurchases: 98000, totalPayments: 98000, remainingPayable: 0, notes: "Gravinate and Hydryllin supplier" },
        { id: "COMP-104", name: "Al-Shifa Surgical Supplies", contactPerson: "Haji Usman", phone: "03459988776", whatsapp: "923459988776", address: "Bank Road, Mardan", email: "alshifasurgical@gmail.com", openingBalance: 0, totalPurchases: 90000, totalPayments: 75000, remainingPayable: 15000, notes: "Surgical gloves, syringes, and catheters" }
      ];

      const INITIAL_CUSTOMERS = [
        { id: "CUST-101", name: "Shahab Khan", shopName: "Khyber Medico Store", phone: "03451122334", whatsapp: "923451122334", address: "DHQ Hospital Road, Mardan", openingBalance: 0, totalPurchases: 125000, totalPaid: 95000, remainingBalance: 30000 },
        { id: "CUST-102", name: "Dr. Farooq Ahmad", shopName: "Al-Razi Pharmacy", phone: "03124455667", whatsapp: "923124455667", address: "Shamsi Road, Mardan", openingBalance: 0, totalPurchases: 98000, totalPaid: 80000, remainingBalance: 18000 },
        { id: "CUST-103", name: "Zahid Ali", shopName: "Mardan Surgical Complex", phone: "03348877665", whatsapp: "923348877665", address: "Baghdada, Mardan", openingBalance: 0, totalPurchases: 210000, totalPaid: 210000, remainingBalance: 0 },
        { id: "CUST-104", name: "Walk-in Customer", shopName: "Retail / Counter Customer", phone: "03000000000", whatsapp: "", address: "Mardan", openingBalance: 0, totalPurchases: 45000, totalPaid: 45000, remainingBalance: 0 }
      ];

      const INITIAL_PRODUCTS = [
        { id: "PROD-1001", itemNo: "MED-1001", name: "Augmentin 625mg Tablet", genericName: "Co-Amoxiclav", brand: "Augmentin", company: "GSK Pakistan Ltd", category: "Tablets", batchNumber: "AUG-8841", expiryDate: "2027-05-15", tp: 240, salePrice: 280, retailPrice: 310, purchasedQty: 500, availableQty: 320, bonusQty: 0, discount: 5, rackNumber: "Rack A-1", minStockLevel: 50, notes: "Cool dry place" },
        { id: "PROD-1002", itemNo: "MED-1002", name: "Risek 20mg Capsule", genericName: "Omeprazole", brand: "Risek", company: "Getz Pharma", category: "Capsules", batchNumber: "RSK-9912", expiryDate: "2026-11-20", tp: 180, salePrice: 210, retailPrice: 230, purchasedQty: 800, availableQty: 450, bonusQty: 0, discount: 5, rackNumber: "Rack A-2", minStockLevel: 100, notes: "" },
        { id: "PROD-1003", itemNo: "MED-1003", name: "Panadol Extra Tablet", genericName: "Paracetamol / Caffeine", brand: "Panadol Extra", company: "GSK Pakistan Ltd", category: "Tablets", batchNumber: "PND-4410", expiryDate: "2026-09-25", tp: 35, salePrice: 42, retailPrice: 48, purchasedQty: 2000, availableQty: 18, bonusQty: 0, discount: 2, rackNumber: "Rack B-1", minStockLevel: 50, notes: "Near Low Stock" },
        { id: "PROD-1004", itemNo: "MED-1004", name: "Flagyl 400mg Tablet", genericName: "Metronidazole", brand: "Flagyl", company: "Sanofi", category: "Tablets", batchNumber: "FLG-1102", expiryDate: "2025-10-10", tp: 80, salePrice: 95, retailPrice: 105, purchasedQty: 600, availableQty: 120, bonusQty: 0, discount: 5, rackNumber: "Rack B-2", minStockLevel: 40, notes: "" },
        { id: "PROD-1005", itemNo: "MED-1005", name: "Brufen 400mg Tablet", genericName: "Ibuprofen", brand: "Brufen", company: "Abbott", category: "Tablets", batchNumber: "BRF-5541", expiryDate: "2026-10-05", tp: 70, salePrice: 82, retailPrice: 90, purchasedQty: 1000, availableQty: 600, bonusQty: 0, discount: 3, rackNumber: "Rack B-3", minStockLevel: 80, notes: "" },
        { id: "PROD-1006", itemNo: "MED-1006", name: "Cefspan 400mg Capsule", genericName: "Cefixime", brand: "Cefspan", company: "Barrett Hodgson", category: "Capsules", batchNumber: "CFS-7721", expiryDate: "2027-02-14", tp: 340, salePrice: 390, retailPrice: 420, purchasedQty: 300, availableQty: 140, bonusQty: 0, discount: 5, rackNumber: "Rack A-3", minStockLevel: 30, notes: "" },
        { id: "PROD-1007", itemNo: "MED-1007", name: "Surbex Z Tablet", genericName: "Multivitamins + Zinc", brand: "Surbex Z", company: "Abbott", category: "Tablets", batchNumber: "SBX-3390", expiryDate: "2026-09-15", tp: 280, salePrice: 320, retailPrice: 350, purchasedQty: 400, availableQty: 12, bonusQty: 0, discount: 4, rackNumber: "Rack C-1", minStockLevel: 25, notes: "" },
        { id: "PROD-1008", itemNo: "MED-1008", name: "Gravinate Syrup 120ml", genericName: "Dimenhydrinate", brand: "Gravinate", company: "Searle Company Ltd", category: "Syrups", batchNumber: "GRV-1209", expiryDate: "2026-08-30", tp: 65, salePrice: 78, retailPrice: 85, purchasedQty: 300, availableQty: 5, bonusQty: 0, discount: 2, rackNumber: "Rack D-1", minStockLevel: 30, notes: "EXPIRED" },
        { id: "PROD-2001", itemNo: "SURG-2001", name: "Surgical Sterile Gloves 7.5", genericName: "Latex Examination Gloves", brand: "Mediglove", company: "Al-Shifa Surgical Supplies", category: "Surgical Items", batchNumber: "GLV-2024", expiryDate: "2028-12-31", tp: 450, salePrice: 520, retailPrice: 580, purchasedQty: 200, availableQty: 180, bonusQty: 0, discount: 5, rackNumber: "Rack S-1", minStockLevel: 20, notes: "Box of 50" },
        { id: "PROD-2002", itemNo: "SURG-2002", name: "Disposable Syringe 5ml (22G)", genericName: "Plastic Injection Syringe", brand: "Master Syringe", company: "Al-Shifa Surgical Supplies", category: "Disposable Items", batchNumber: "SYR-9081", expiryDate: "2029-06-30", tp: 12, salePrice: 15, retailPrice: 18, purchasedQty: 5000, availableQty: 3400, bonusQty: 0, discount: 10, rackNumber: "Rack S-2", minStockLevel: 500, notes: "Box of 100" },
        { id: "PROD-2003", itemNo: "SURG-2003", name: "IV Cannula 20G Pink", genericName: "Intravenous Catheter", brand: "BD Neoflon", company: "Al-Shifa Surgical Supplies", category: "Surgical Items", batchNumber: "CAN-3311", expiryDate: "2027-08-15", tp: 85, salePrice: 105, retailPrice: 120, purchasedQty: 1000, availableQty: 750, bonusQty: 0, discount: 5, rackNumber: "Rack S-3", minStockLevel: 100, notes: "" },
        { id: "PROD-3001", itemNo: "EQUIP-3001", name: "Digital Blood Pressure Monitor", genericName: "Oscillometric BP Apparatus", brand: "Omron M2", company: "Omron Healthcare", category: "Medical Equipment", batchNumber: "OMR-8812", expiryDate: "2030-01-01", tp: 4800, salePrice: 5500, retailPrice: 6200, purchasedQty: 25, availableQty: 14, bonusQty: 0, discount: 2, rackNumber: "Rack E-1", minStockLevel: 5, notes: "1 Year Warranty" }
      ];

      const INITIAL_PURCHASES = [
        { id: "PUR-10001", purchaseNumber: "MYU-PUR-000001", invoiceNumber: "GSK-INV-9921", date: Utils.todayStr(-15), time: "10:30 AM", companyId: "COMP-101", companyName: "GSK Pakistan Ltd", companyContact: "03001234567", paymentType: "Credit", items: [{ productId: "PROD-1001", itemNo: "MED-1001", name: "Augmentin 625mg Tablet", batchNumber: "AUG-8841", expiryDate: "2027-05-15", quantity: 500, bonus: 0, tp: 240, discountPercent: 5, discountAmount: 6000, tax: 0, netPrice: 228, totalAmount: 114000 }], subtotal: 120000, totalDiscount: 6000, tax: 0, grandTotal: 114000, paidAmount: 79000, remainingAmount: 35000, notes: "First monthly bulk order" },
        { id: "PUR-10002", purchaseNumber: "MYU-PUR-000002", invoiceNumber: "GTZ-INV-4412", date: Utils.todayStr(-5), time: "02:15 PM", companyId: "COMP-102", companyName: "Getz Pharma", companyContact: "03139876543", paymentType: "Partial Payment", items: [{ productId: "PROD-1002", itemNo: "MED-1002", name: "Risek 20mg Capsule", batchNumber: "RSK-9912", expiryDate: "2026-11-20", quantity: 800, bonus: 0, tp: 180, discountPercent: 5, discountAmount: 7200, tax: 0, netPrice: 171, totalAmount: 136800 }], subtotal: 144000, totalDiscount: 7200, tax: 0, grandTotal: 136800, paidAmount: 112800, remainingAmount: 24000, notes: "Capsules consignment" }
      ];

      const INITIAL_SALES = [
        { id: "SALE-10001", invoiceNumber: "MYU-INV-000001", date: Utils.todayStr(0), time: "11:15 AM", customerId: "CUST-101", customerName: "Shahab Khan", customerShop: "Khyber Medico Store", customerPhone: "03451122334", customerAddress: "DHQ Hospital Road, Mardan", paymentMethod: "Credit", items: [{ productId: "PROD-1001", itemNo: "MED-1001", name: "Augmentin 625mg Tablet", batchNumber: "AUG-8841", expiryDate: "2027-05-15", quantity: 50, price: 280, tp: 240, discountPercent: 5, discountAmount: 700, bonus: 0, totalAmount: 13300, itemProfit: 2000 }, { productId: "PROD-1002", itemNo: "MED-1002", name: "Risek 20mg Capsule", batchNumber: "RSK-9912", expiryDate: "2026-11-20", quantity: 100, price: 210, tp: 180, discountPercent: 5, discountAmount: 1050, bonus: 0, totalAmount: 19950, itemProfit: 3000 }], grossTotal: 35000, totalDiscount: 1750, tax: 0, previousBalance: 0, netAmount: 33250, paidAmount: 3250, remainingBalance: 30000, totalProfit: 5000, status: "Partially Paid" },
        { id: "SALE-10002", invoiceNumber: "MYU-INV-000002", date: Utils.todayStr(0), time: "03:45 PM", customerId: "CUST-102", customerName: "Dr. Farooq Ahmad", customerShop: "Al-Razi Pharmacy", customerPhone: "03124455667", customerAddress: "Shamsi Road, Mardan", paymentMethod: "Credit", items: [{ productId: "PROD-2002", itemNo: "SURG-2002", name: "Disposable Syringe 5ml (22G)", batchNumber: "SYR-9081", expiryDate: "2029-06-30", quantity: 1000, price: 15, tp: 12, discountPercent: 10, discountAmount: 1500, bonus: 50, totalAmount: 13500, itemProfit: 3000 }], grossTotal: 15000, totalDiscount: 1500, tax: 0, previousBalance: 0, netAmount: 13500, paidAmount: 5000, remainingBalance: 8500, totalProfit: 3000, status: "Partially Paid" },
        { id: "SALE-10003", invoiceNumber: "MYU-INV-000003", date: Utils.todayStr(-2), time: "01:20 PM", customerId: "CUST-104", customerName: "Walk-in Customer", customerShop: "Retail", customerPhone: "03000000000", customerAddress: "Mardan", paymentMethod: "Cash", items: [{ productId: "PROD-3001", itemNo: "EQUIP-3001", name: "Digital Blood Pressure Monitor", batchNumber: "OMR-8812", expiryDate: "2030-01-01", quantity: 1, price: 5500, tp: 4800, discountPercent: 0, discountAmount: 0, bonus: 0, totalAmount: 5500, itemProfit: 700 }], grossTotal: 5500, totalDiscount: 0, tax: 0, previousBalance: 0, netAmount: 5500, paidAmount: 5500, remainingBalance: 0, totalProfit: 700, status: "Paid" }
      ];

      const INITIAL_EXPENSES = [
        { id: "EXP-1001", date: Utils.todayStr(-1), category: "Office Expense", title: "Shop Electricity & Utility Bill", amount: 4500, paymentMethod: "Cash", notes: "PESCO electricity bill" },
        { id: "EXP-1002", date: Utils.todayStr(-3), category: "Home Expense", title: "Monthly Household Grocery", amount: 12000, paymentMethod: "Cash", notes: "Personal home expense" },
        { id: "EXP-1003", date: Utils.todayStr(-5), category: "Salaries", title: "Staff Salary - Helper", amount: 18000, paymentMethod: "Bank Transfer", notes: "Monthly helper wages" }
      ];

      const INITIAL_INCOMES = [
        { id: "INC-1001", date: Utils.todayStr(-2), category: "Other Income", title: "Used Packing Cartons Sale", amount: 1500, notes: "Recycling scrap revenue" }
      ];

      class StorageManager {
        constructor() { this.init(); }
        init() {
          const isCleared = localStorage.getItem('myu_demo_cleared_v1') === 'true';
          if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
          if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(isCleared ? [] : INITIAL_PRODUCTS));
          if (!localStorage.getItem(STORAGE_KEYS.COMPANIES)) localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify(isCleared ? [] : INITIAL_COMPANIES));
          if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(isCleared ? [] : INITIAL_CUSTOMERS));
          if (!localStorage.getItem(STORAGE_KEYS.PURCHASES)) localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(isCleared ? [] : INITIAL_PURCHASES));
          if (!localStorage.getItem(STORAGE_KEYS.SALES)) localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(isCleared ? [] : INITIAL_SALES));
          if (!localStorage.getItem(STORAGE_KEYS.SUPPLIER_PAYMENTS)) localStorage.setItem(STORAGE_KEYS.SUPPLIER_PAYMENTS, JSON.stringify([]));
          if (!localStorage.getItem(STORAGE_KEYS.CUSTOMER_PAYMENTS)) localStorage.setItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, JSON.stringify([]));
          if (!localStorage.getItem(STORAGE_KEYS.EXPENSES)) localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(isCleared ? [] : INITIAL_EXPENSES));
          if (!localStorage.getItem(STORAGE_KEYS.INCOMES)) localStorage.setItem(STORAGE_KEYS.INCOMES, JSON.stringify(isCleared ? [] : INITIAL_INCOMES));
          if (!localStorage.getItem(STORAGE_KEYS.RETURNS)) localStorage.setItem(STORAGE_KEYS.RETURNS, JSON.stringify([]));
        }

        clearAllData() {
          localStorage.clear();
          localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
          localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.SUPPLIER_PAYMENTS, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.INCOMES, JSON.stringify([]));
          localStorage.setItem(STORAGE_KEYS.RETURNS, JSON.stringify([]));
          localStorage.setItem('myu_demo_cleared_v1', 'true');
        }

        get(key, fallback = []) {
          try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (e) { return fallback; }
        }
        set(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

        getSettings() { return { ...DEFAULT_SETTINGS, ...this.get(STORAGE_KEYS.SETTINGS, {}) }; }
        saveSettings(s) { this.set(STORAGE_KEYS.SETTINGS, s); }

        getExpenses() { return this.get(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES); }
        saveExpenses(list) { this.set(STORAGE_KEYS.EXPENSES, list); }
        addExpense(data) {
          const list = this.getExpenses();
          const item = {
            id: "EXP-" + Date.now(),
            date: data.date || Utils.todayStr(),
            category: data.category || "Office Expense",
            title: data.title || "Misc Expense",
            amount: parseFloat(data.amount) || 0,
            paymentMethod: data.paymentMethod || "Cash",
            notes: data.notes || ""
          };
          list.push(item);
          this.saveExpenses(list);
          return item;
        }
        deleteExpense(id) {
          const list = this.getExpenses();
          this.saveExpenses(list.filter(e => e.id !== id));
        }

        getManualIncomes() { return this.get(STORAGE_KEYS.INCOMES, INITIAL_INCOMES); }
        saveManualIncomes(list) { this.set(STORAGE_KEYS.INCOMES, list); }
        addManualIncome(data) {
          const list = this.getManualIncomes();
          const item = {
            id: "INC-" + Date.now(),
            date: data.date || Utils.todayStr(),
            category: data.category || "Other Income",
            title: data.title || "Extra Income",
            amount: parseFloat(data.amount) || 0,
            notes: data.notes || ""
          };
          list.push(item);
          this.saveManualIncomes(list);
          return item;
        }
        deleteManualIncome(id) {
          const list = this.getManualIncomes();
          this.saveManualIncomes(list.filter(i => i.id !== id));
        }

        getProducts() { return this.get(STORAGE_KEYS.PRODUCTS, []); }
        saveProducts(p) { this.set(STORAGE_KEYS.PRODUCTS, p); }

        getCompanies() { return this.get(STORAGE_KEYS.COMPANIES, []); }
        saveCompanies(c) { this.set(STORAGE_KEYS.COMPANIES, c); }

        getCustomers() { return this.get(STORAGE_KEYS.CUSTOMERS, []); }
        saveCustomers(c) { this.set(STORAGE_KEYS.CUSTOMERS, c); }

        getPurchases() { return this.get(STORAGE_KEYS.PURCHASES, []); }
        savePurchases(p) { this.set(STORAGE_KEYS.PURCHASES, p); }

        getSales() { return this.get(STORAGE_KEYS.SALES, []); }
        saveSales(s) { this.set(STORAGE_KEYS.SALES, s); }

        getSupplierPayments() { return this.get(STORAGE_KEYS.SUPPLIER_PAYMENTS, []); }
        saveSupplierPayments(p) { this.set(STORAGE_KEYS.SUPPLIER_PAYMENTS, p); }

        getCustomerPayments() { return this.get(STORAGE_KEYS.CUSTOMER_PAYMENTS, []); }
        saveCustomerPayments(p) { this.set(STORAGE_KEYS.CUSTOMER_PAYMENTS, p); }

        getReturns() { return this.get(STORAGE_KEYS.RETURNS, []); }
        saveReturns(r) { this.set(STORAGE_KEYS.RETURNS, r); }

        addReturn(data) {
          const list = this.getReturns();
          const products = this.getProducts();
          const customers = this.getCustomers();

          const returnNum = "MYU-RET-" + String(list.length + 1).padStart(6, '0');
          const item = {
            id: "RET-" + Date.now(),
            returnNumber: returnNum,
            saleId: data.saleId,
            invoiceNumber: data.invoiceNumber,
            date: data.date || Utils.todayStr(),
            time: data.time || Utils.nowTimeStr(),
            customerId: data.customerId || "",
            customerName: data.customerName || "Walk-in Customer",
            items: data.items || [],
            totalRefundAmount: parseFloat(data.totalRefundAmount) || 0,
            totalProfitReversed: parseFloat(data.totalProfitReversed) || 0,
            paymentMethod: data.paymentMethod || "Cash",
            reason: data.reason || "Customer Return",
            notes: data.notes || ""
          };

          // Restock returned items to Inventory
          (item.items || []).forEach(ri => {
            const pIdx = products.findIndex(p => (ri.productId && p.id === ri.productId) || (ri.itemNo && p.itemNo === ri.itemNo) || (ri.name && p.name === ri.name));
            if (pIdx !== -1) {
              const rQty = parseInt(ri.returnQty) || 0;
              products[pIdx].availableQty = (products[pIdx].availableQty || 0) + rQty;
            }
          });
          this.saveProducts(products);

          // Update customer credit ledger if customer exists
          if (item.customerId || item.customerName) {
            const cIdx = customers.findIndex(c => (item.customerId && c.id === item.customerId) || (item.customerName && c.name === item.customerName));
            if (cIdx !== -1) {
              const refund = item.totalRefundAmount;
              customers[cIdx].totalPurchases = Math.max(0, (customers[cIdx].totalPurchases || 0) - refund);
              if (item.paymentMethod === 'Credit Adjustment' || item.paymentMethod === 'Credit Balance Adjustment' || customers[cIdx].remainingBalance > 0) {
                customers[cIdx].remainingBalance = Math.max(0, (customers[cIdx].remainingBalance || 0) - refund);
              }
              this.saveCustomers(customers);
            }
          }

          list.push(item);
          this.saveReturns(list);
          return item;
        }

        deleteReturn(id) {
          const list = this.getReturns();
          const item = list.find(r => r.id === id);
          if (item) {
            // Reverse stock addition
            const products = this.getProducts();
            (item.items || []).forEach(ri => {
              const pIdx = products.findIndex(p => (ri.productId && p.id === ri.productId) || (ri.itemNo && p.itemNo === ri.itemNo) || (ri.name && p.name === ri.name));
              if (pIdx !== -1) {
                const rQty = parseInt(ri.returnQty) || 0;
                products[pIdx].availableQty = Math.max(0, (products[pIdx].availableQty || 0) - rQty);
              }
            });
            this.saveProducts(products);
            this.saveReturns(list.filter(r => r.id !== id));
          }
        }

        // CRUD Helpers
        addProduct(data) {
          const list = this.getProducts();
          const item = { id: "PROD-" + Date.now(), itemNo: data.itemNo || "MED-" + (1000 + list.length + 1), name: data.name, genericName: data.genericName || "", brand: data.brand || "", company: data.company || "", category: data.category || "Medicines", batchNumber: data.batchNumber || "B-" + Math.floor(1000 + Math.random() * 9000), expiryDate: data.expiryDate || "", tp: parseFloat(data.tp) || 0, salePrice: parseFloat(data.salePrice) || 0, retailPrice: parseFloat(data.retailPrice) || parseFloat(data.salePrice) || 0, purchasedQty: parseInt(data.purchasedQty) || 0, availableQty: parseInt(data.availableQty) || 0, bonusQty: parseInt(data.bonusQty) || 0, discount: parseFloat(data.discount) || 0, rackNumber: data.rackNumber || "", minStockLevel: parseInt(data.minStockLevel) || 10, notes: data.notes || "" };
          list.push(item); this.saveProducts(list); return item;
        }

        updateProduct(id, data) {
          const list = this.getProducts();
          const idx = list.findIndex(p => p.id === id);
          if (idx !== -1) { list[idx] = { ...list[idx], ...data }; this.saveProducts(list); return list[idx]; }
          return null;
        }

        deleteProduct(id) { this.saveProducts(this.getProducts().filter(p => p.id !== id)); }

        addCompany(data) {
          const list = this.getCompanies();
          const item = { id: "COMP-" + Date.now(), name: data.name, contactPerson: data.contactPerson || "", phone: data.phone || "", whatsapp: data.whatsapp || "", email: data.email || "", address: data.address || "", openingBalance: parseFloat(data.openingBalance) || 0, totalPurchases: parseFloat(data.openingBalance) || 0, totalPayments: 0, remainingPayable: parseFloat(data.openingBalance) || 0, notes: data.notes || "" };
          list.push(item); this.saveCompanies(list); return item;
        }

        updateCompany(id, data) {
          const list = this.getCompanies();
          const idx = list.findIndex(c => c.id === id);
          if (idx !== -1) { list[idx] = { ...list[idx], ...data }; this.saveCompanies(list); return list[idx]; }
          return null;
        }

        deleteCompany(id) { this.saveCompanies(this.getCompanies().filter(c => c.id !== id)); }

        addCustomer(data) {
          const list = this.getCustomers();
          const item = { id: "CUST-" + Date.now(), name: data.name, shopName: data.shopName || "", phone: data.phone || "", whatsapp: data.whatsapp || "", address: data.address || "", openingBalance: parseFloat(data.openingBalance) || 0, totalPurchases: parseFloat(data.openingBalance) || 0, totalPaid: 0, remainingBalance: parseFloat(data.openingBalance) || 0 };
          list.push(item); this.saveCustomers(list); return item;
        }

        updateCustomer(id, data) {
          const list = this.getCustomers();
          const idx = list.findIndex(c => c.id === id);
          if (idx !== -1) { list[idx] = { ...list[idx], ...data }; this.saveCustomers(list); return list[idx]; }
          return null;
        }

        deleteCustomer(id) { this.saveCustomers(this.getCustomers().filter(c => c.id !== id)); }

        addPurchase(data) {
          const purchases = this.getPurchases();
          const products = this.getProducts();
          const companies = this.getCompanies();
          const settings = this.getSettings();

          const num = data.purchaseNumber || (settings.purchasePrefix + String(purchases.length + 1).padStart(6, '0'));
          const newPur = { id: "PUR-" + Date.now(), purchaseNumber: num, invoiceNumber: data.invoiceNumber || "", date: data.date || Utils.todayStr(), time: data.time || Utils.nowTimeStr(), companyId: data.companyId, companyName: data.companyName, companyContact: data.companyContact || "", paymentType: data.paymentType || "Cash", items: data.items || [], subtotal: parseFloat(data.subtotal) || 0, totalDiscount: parseFloat(data.totalDiscount) || 0, tax: parseFloat(data.tax) || 0, grandTotal: parseFloat(data.grandTotal) || 0, paidAmount: parseFloat(data.paidAmount) || 0, remainingAmount: parseFloat(data.remainingAmount) || 0, notes: data.notes || "" };

          purchases.push(newPur);
          this.savePurchases(purchases);

          // Update product inventory
          newPur.items.forEach(item => {
            const idx = products.findIndex(p => p.id === item.productId || p.itemNo === item.itemNo);
            if (idx !== -1) {
              const addQty = (parseInt(item.quantity) || 0) + (parseInt(item.bonus) || 0);
              products[idx].purchasedQty = (products[idx].purchasedQty || 0) + parseInt(item.quantity);
              products[idx].bonusQty = (products[idx].bonusQty || 0) + (parseInt(item.bonus) || 0);
              products[idx].availableQty = (products[idx].availableQty || 0) + addQty;
              if (item.batchNumber) products[idx].batchNumber = item.batchNumber;
              if (item.expiryDate) products[idx].expiryDate = item.expiryDate;
              if (item.tp) products[idx].tp = parseFloat(item.tp);
            }
          });
          this.saveProducts(products);

          // Update company balance
          if (newPur.companyId) {
            const cIdx = companies.findIndex(c => c.id === newPur.companyId);
            if (cIdx !== -1) {
              companies[cIdx].totalPurchases += newPur.grandTotal;
              companies[cIdx].totalPayments += newPur.paidAmount;
              companies[cIdx].remainingPayable += newPur.remainingAmount;
              this.saveCompanies(companies);
            }
          }
          return newPur;
        }

        addSale(data) {
          const sales = this.getSales();
          const products = this.getProducts();
          const customers = this.getCustomers();
          const settings = this.getSettings();

          const invNum = data.invoiceNumber || (settings.invoicePrefix + String(sales.length + 1).padStart(6, '0'));
          let calculatedProfit = 0;

          const saleItems = (data.items || []).map(item => {
            const qty = parseInt(item.quantity) || 0;
            const price = parseFloat(item.price) || 0;
            const tp = parseFloat(item.tp) || 0;
            const discPercent = parseFloat(item.discountPercent) || 0;
            const extPercent = parseFloat(item.extPercent) || 0;
            const taxPercent = parseFloat(item.taxPercent) || 0;
            const lineAmount = item.totalAmount !== undefined ? parseFloat(item.totalAmount) : Utils.calcWholesaleLine(qty, price, item.bonus || 0, discPercent, extPercent, taxPercent, tp).lineAmount;
            const profit = item.itemProfit !== undefined ? parseFloat(item.itemProfit) : (lineAmount - (tp * qty));
            calculatedProfit += profit;
            return { ...item, totalAmount: lineAmount, itemProfit: profit };
          });

          const newSale = { id: "SALE-" + Date.now(), invoiceNumber: invNum, date: data.date || Utils.todayStr(), time: data.time || Utils.nowTimeStr(), customerId: data.customerId || "CUST-104", customerName: data.customerName || "Walk-in Customer", customerShop: data.customerShop || "", customerPhone: data.customerPhone || "", customerAddress: data.customerAddress || "", paymentMethod: data.paymentMethod || "Cash", items: saleItems, grossTotal: parseFloat(data.grossTotal) || 0, totalDiscount: parseFloat(data.totalDiscount) || 0, tax: parseFloat(data.tax) || 0, previousBalance: parseFloat(data.previousBalance) || 0, netAmount: parseFloat(data.netAmount) || 0, paidAmount: parseFloat(data.paidAmount) || 0, remainingBalance: parseFloat(data.remainingBalance) || 0, totalProfit: calculatedProfit, status: data.remainingBalance <= 0 ? "Paid" : (data.paidAmount > 0 ? "Partially Paid" : "Unpaid") };

          sales.push(newSale);
          this.saveSales(sales);

          // Reduce stock
          saleItems.forEach(item => {
            const idx = products.findIndex(p => p.id === item.productId || p.itemNo === item.itemNo);
            if (idx !== -1) {
              const reduceQty = (parseInt(item.quantity) || 0) + (parseInt(item.bonus) || 0);
              products[idx].availableQty = Math.max(0, (products[idx].availableQty || 0) - reduceQty);
            }
          });
          this.saveProducts(products);

          // Update customer balance
          if (newSale.customerId) {
            const cIdx = customers.findIndex(c => c.id === newSale.customerId);
            if (cIdx !== -1) {
              customers[cIdx].totalPurchases += newSale.netAmount;
              customers[cIdx].totalPaid += newSale.paidAmount;
              customers[cIdx].remainingBalance += newSale.remainingBalance;
              this.saveCustomers(customers);
            }
          }
          return newSale;
        }

        updateSalePayment(id, newPaidAmount, newPaymentMethod = 'Cash', adjustmentNotes = '') {
          const sales = this.getSales();
          const customers = this.getCustomers();

          const sIdx = sales.findIndex(s => s.id === id || s.invoiceNumber === id);
          if (sIdx === -1) return null;

          const sale = sales[sIdx];
          const oldPaid = parseFloat(sale.paidAmount) || 0;
          const oldRemaining = parseFloat(sale.remainingBalance) || 0;
          const netAmount = parseFloat(sale.netAmount) || 0;

          const paid = Math.max(0, parseFloat(newPaidAmount) || 0);
          const newRemaining = Math.max(0, netAmount - paid);
          const newStatus = newRemaining <= 0 ? "Paid" : (paid > 0 ? "Partially Paid" : "Unpaid");

          const paidDiff = paid - oldPaid;
          const remainingDiff = newRemaining - oldRemaining;

          sale.paidAmount = paid;
          sale.remainingBalance = newRemaining;
          sale.status = newStatus;
          if (newPaymentMethod) sale.paymentMethod = newPaymentMethod;
          if (adjustmentNotes) {
            sale.notes = sale.notes ? `${sale.notes} | ${adjustmentNotes}` : adjustmentNotes;
          }

          sales[sIdx] = sale;
          this.saveSales(sales);

          // Update customer balance ledger if customerId exists
          if (sale.customerId) {
            const cIdx = customers.findIndex(c => c.id === sale.customerId);
            if (cIdx !== -1) {
              customers[cIdx].totalPaid = Math.max(0, (customers[cIdx].totalPaid || 0) + paidDiff);
              customers[cIdx].remainingBalance = Math.max(0, (customers[cIdx].remainingBalance || 0) + remainingDiff);
              this.saveCustomers(customers);
            }
          }

          return sale;
        }

        addSupplierPayment(data) {
          const payments = this.getSupplierPayments();
          const companies = this.getCompanies();
          const item = { id: "SPAY-" + Date.now(), companyId: data.companyId, companyName: data.companyName, purchaseInvoice: data.purchaseInvoice || "Direct Payment", date: data.date || Utils.todayStr(), amount: parseFloat(data.amount) || 0, method: data.method || "Cash", reference: data.reference || "", notes: data.notes || "" };

          payments.push(item); this.saveSupplierPayments(payments);
          const idx = companies.findIndex(c => c.id === data.companyId);
          if (idx !== -1) {
            companies[idx].totalPayments += item.amount;
            companies[idx].remainingPayable = Math.max(0, companies[idx].remainingPayable - item.amount);
            this.saveCompanies(companies);
          }
          return item;
        }

        addCustomerPayment(data) {
          const payments = this.getCustomerPayments();
          const customers = this.getCustomers();
          const item = { id: "CPAY-" + Date.now(), customerId: data.customerId, customerName: data.customerName, saleInvoice: data.saleInvoice || "Direct Credit Payment", date: data.date || Utils.todayStr(), amount: parseFloat(data.amount) || 0, method: data.method || "Cash", reference: data.reference || "", notes: data.notes || "" };

          payments.push(item); this.saveCustomerPayments(payments);
          const idx = customers.findIndex(c => c.id === data.customerId);
          if (idx !== -1) {
            customers[idx].totalPaid += item.amount;
            customers[idx].remainingBalance = Math.max(0, customers[idx].remainingBalance - item.amount);
            this.saveCustomers(customers);
          }
          return item;
        }

        deletePurchase(id) {
          let list = this.getPurchases();
          const item = list.find(p => p.id === id);
          if (item) {
            if (item.companyId) {
              const companies = this.getCompanies();
              const cIdx = companies.findIndex(c => c.id === item.companyId);
              if (cIdx !== -1) {
                companies[cIdx].totalPurchases -= item.grandTotal;
                companies[cIdx].totalPayments -= item.paidAmount;
                companies[cIdx].remainingPayable -= item.remainingAmount;
                this.saveCompanies(companies);
              }
            }
            const products = this.getProducts();
            item.items.forEach(i => {
              const idx = products.findIndex(p => p.id === i.productId || p.itemNo === i.itemNo);
              if (idx !== -1) {
                const qty = (parseInt(i.quantity) || 0) + (parseInt(i.bonus) || 0);
                products[idx].availableQty = Math.max(0, (products[idx].availableQty || 0) - qty);
              }
            });
            this.saveProducts(products);
            this.savePurchases(list.filter(p => p.id !== id));
          }
        }

        deleteSale(id) {
          let list = this.getSales();
          const item = list.find(s => (s.id && s.id === id) || (s.invoiceNumber && s.invoiceNumber === id));
          if (item) {
            if (item.customerId) {
              const customers = this.getCustomers();
              const cIdx = customers.findIndex(c => c.id === item.customerId);
              if (cIdx !== -1) {
                customers[cIdx].totalPurchases = Math.max(0, customers[cIdx].totalPurchases - item.netAmount);
                customers[cIdx].totalPaid = Math.max(0, customers[cIdx].totalPaid - item.paidAmount);
                customers[cIdx].remainingBalance = Math.max(0, customers[cIdx].remainingBalance - item.remainingBalance);
                this.saveCustomers(customers);
              }
            }
            const products = this.getProducts();
            item.items.forEach(i => {
              const idx = products.findIndex(p => p.id === i.productId || p.itemNo === i.itemNo);
              if (idx !== -1) {
                const qty = (parseInt(i.quantity) || 0) + (parseInt(i.bonus) || 0);
                products[idx].availableQty += qty;
              }
            });
            this.saveProducts(products);
            this.saveSales(list.filter(s => s !== item && (item.id ? s.id !== item.id : true) && (item.invoiceNumber ? s.invoiceNumber !== item.invoiceNumber : true)));
          }
        }

        getDashboardStats() {
          const sales = this.getSales();
          const purchases = this.getPurchases();
          const products = this.getProducts();
          const companies = this.getCompanies();
          const customers = this.getCustomers();

          const todayStr = Utils.todayStr(0);
          const thisMonthStr = todayStr.substring(0, 7);
          const thisYearStr = todayStr.substring(0, 4);

          let todaySales = 0, monthSales = 0, yearSales = 0, todayProfit = 0, monthProfit = 0;
          sales.forEach(s => {
            const sDate = s.date || "";
            if (sDate === todayStr) { todaySales += s.netAmount || 0; todayProfit += s.totalProfit || 0; }
            if (sDate.startsWith(thisMonthStr)) { monthSales += s.netAmount || 0; monthProfit += s.totalProfit || 0; }
            if (sDate.startsWith(thisYearStr)) { yearSales += s.netAmount || 0; }
          });

          const returns = this.getReturns();
          returns.forEach(r => {
            const rDate = r.date || "";
            const rRefund = r.totalRefundAmount || 0;
            const rProf = r.totalProfitReversed || 0;
            if (rDate === todayStr) { todaySales -= rRefund; todayProfit -= rProf; }
            if (rDate.startsWith(thisMonthStr)) { monthSales -= rRefund; monthProfit -= rProf; }
            if (rDate.startsWith(thisYearStr)) { yearSales -= rRefund; }
          });

          let totalAvailableQty = 0, lowStockCount = 0, outOfStockCount = 0;
          products.forEach(p => {
            const qty = parseInt(p.availableQty) || 0;
            const minStock = parseInt(p.minStockLevel) || 10;
            totalAvailableQty += qty;
            if (qty <= 0) outOfStockCount++;
            else if (qty <= minStock) lowStockCount++;
          });

          return {
            todaySales, monthSales, yearSales, todayProfit, monthProfit,
            totalProducts: products.length, totalAvailableQty, lowStockCount, outOfStockCount,
            totalPurchasesAmt: purchases.reduce((a, b) => a + (b.grandTotal || 0), 0),
            companyPayables: companies.reduce((a, b) => a + (b.remainingPayable || 0), 0),
            customerReceivables: customers.reduce((a, b) => a + (b.remainingBalance || 0), 0)
          };
        }

        getExpiryStatus() {
          const products = this.getProducts();
          var today = window.today || new Date(); today.setHours(0, 0, 0, 0);
          const expired = [], within30 = [], within60 = [], within90 = [];

          products.forEach(p => {
            if (!p.expiryDate) return;
            const exp = new Date(p.expiryDate);
            const diffDays = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));
            const item = { ...p, daysRemaining: diffDays };

            if (diffDays < 0) expired.push(item);
            else if (diffDays <= 30) within30.push(item);
            else if (diffDays <= 60) within60.push(item);
            else if (diffDays <= 90) within90.push(item);
          });

          return { expired, within30, within60, within90 };
        }

        exportJSON() {
          return JSON.stringify({
            settings: this.getSettings(), products: this.getProducts(), companies: this.getCompanies(),
            customers: this.getCustomers(), purchases: this.getPurchases(), sales: this.getSales(),
            supplierPayments: this.getSupplierPayments(), customerPayments: this.getCustomerPayments(),
            expenses: this.getExpenses(), incomes: this.getManualIncomes(), returns: this.getReturns(),
            exportDate: new Date().toISOString()
          }, null, 2);
        }

        importJSON(jsonString) {
          try {
            const data = JSON.parse(jsonString);
            if (data.settings) this.saveSettings(data.settings);
            if (data.products) this.saveProducts(data.products);
            if (data.companies) this.saveCompanies(data.companies);
            if (data.customers) this.saveCustomers(data.customers);
            if (data.purchases) this.savePurchases(data.purchases);
            if (data.sales) this.saveSales(data.sales);
            if (data.supplierPayments) this.saveSupplierPayments(data.supplierPayments);
            if (data.customerPayments) this.saveCustomerPayments(data.customerPayments);
            if (data.expenses) this.saveExpenses(data.expenses);
            if (data.incomes) this.saveManualIncomes(data.incomes);
            if (data.returns) this.saveReturns(data.returns);
            return true;
          } catch (e) { return false; }
        }
      }

      var storage = window.storage || new StorageManager();
      window.storage = storage;


      /* ==================== MAIN APP CONTROLLER ==================== */

if (typeof global !== 'undefined') {
  global.StorageManager = StorageManager;
  if (typeof storage !== 'undefined') global.storage = storage;
}
if (typeof window !== 'undefined') {
  window.StorageManager = StorageManager;
  if (typeof storage !== 'undefined') window.storage = storage;
}

