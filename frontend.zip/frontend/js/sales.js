/* ==================== SALES, CUSTOMERS & RETURNS MODULE ==================== */
class SalesModule {
        constructor() { this.bindEvents(); }

        bindEvents() {
          const search = document.getElementById('sales-search-input');
          const dateFilter = document.getElementById('sales-date-filter');
          const statusFilter = document.getElementById('sales-status-filter');

          if (search) search.addEventListener('input', () => this.renderSalesHistory());
          if (dateFilter) dateFilter.addEventListener('change', () => this.renderSalesHistory());
          if (statusFilter) statusFilter.addEventListener('change', () => this.renderSalesHistory());

          const custForm = document.getElementById('customer-form');
          if (custForm) custForm.addEventListener('submit', (e) => { e.preventDefault(); this.saveCustomerForm(); });

          const cpayForm = document.getElementById('customer-payment-form');
          if (cpayForm) cpayForm.addEventListener('submit', (e) => { e.preventDefault(); this.saveCustomerPaymentForm(); });
        }

        renderSalesHistory() {
          const tbody = document.getElementById('sales-history-tbody');
          if (!tbody) return;

          const sales = storage.getSales();
          const settings = storage.getSettings();

          const query = (document.getElementById('sales-search-input').value || '').toLowerCase().trim();
          const dateVal = document.getElementById('sales-date-filter').value || '';
          const statusVal = document.getElementById('sales-status-filter').value || '';

          const filtered = sales.filter(s => {
            const matchQuery = !query || s.invoiceNumber.toLowerCase().includes(query) || s.customerName.toLowerCase().includes(query) || (s.customerShop || '').toLowerCase().includes(query);
            return matchQuery && (!dateVal || s.date === dateVal) && (!statusVal || s.status === statusVal);
          });

          if (!filtered.length) { Utils.emptyTable(tbody, 10, 'No sales invoices found matching filters.'); return; }

          let html = '';
          filtered.slice().reverse().forEach(s => {
            html += `
            <tr>
              <td><span style="font-weight: 700; color: var(--primary);">${s.invoiceNumber}</span></td>
              <td><div style="font-size: 0.85rem; font-weight: 600;">${s.date}</div><div style="font-size: 0.72rem; color: var(--text-muted);">${s.time || ''}</div></td>
              <td><div style="font-weight: 700;">${s.customerName}</div><div style="font-size: 0.75rem; color: var(--text-muted);">${s.customerShop || ''}</div></td>
              <td style="font-weight: 800;">${Utils.formatCurrency(s.netAmount, settings.currency)}</td>
              <td style="color: #059669;">${Utils.formatCurrency(s.totalDiscount, settings.currency)}</td>
              <td style="color: #059669; font-weight: 600;">${Utils.formatCurrency(s.paidAmount, settings.currency)}</td>
              <td style="color: #ef4444; font-weight: 700;">${Utils.formatCurrency(s.remainingBalance, settings.currency)}</td>
              <td style="color: #10b981; font-weight: 700;">${Utils.formatCurrency(s.totalProfit, settings.currency)}</td>
              <td>${Utils.badge(s.status)}</td>
              <td>
                <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                  <button class="btn-primary-myu btn-sm-myu" style="padding: 4px 8px; font-size: 0.78rem;" onclick="salesModule.printInvoiceDirect('${s.id || s.invoiceNumber}')" title="Print Invoice"><i class="fa-solid fa-print"></i> Print</button>
                  <button class="btn-secondary-myu btn-sm-myu" onclick="salesModule.viewInvoiceModal('${s.id || s.invoiceNumber}')" title="View Invoice Modal"><i class="fa-solid fa-eye"></i> View</button>
                  <button class="btn-sm-myu" style="background: #f59e0b; color: #ffffff; border: none; font-weight: 700; padding: 4px 8px; font-size: 0.78rem;" onclick="salesModule.openReturnModal('${s.invoiceNumber}')" title="Process Return for Invoice"><i class="fa-solid fa-rotate-left"></i> Return</button>
                  <button class="btn-sm-myu" style="background: #0284c7; color: #ffffff; border: none; font-weight: 700; padding: 4px 8px; font-size: 0.78rem;" onclick="salesModule.openEditSaleModal('${s.id || s.invoiceNumber}')" title="Edit Payment & Remaining Balance"><i class="fa-solid fa-pen-to-square"></i> Edit</button>
                  <button class="btn-danger-myu btn-sm-myu" onclick="salesModule.deleteSale('${s.id || s.invoiceNumber}')" title="Delete Invoice"><i class="fa-solid fa-trash"></i></button>
                </div>
              </td>
            </tr>
          `;
          });
          tbody.innerHTML = html;
        }

        viewInvoiceModal(saleId) {
          const sales = storage.getSales();
          const sale = sales.find(s => (s.id && s.id === saleId) || (s.invoiceNumber && s.invoiceNumber === saleId));
          if (!sale) return;

          const settings = storage.getSettings();
          const container = document.getElementById('invoice-modal-content');
          if (container) {
            container.innerHTML = this.buildInvoiceTemplate(sale, settings);
          }

          const printBtn = document.getElementById('btn-modal-print-invoice');
          if (printBtn) {
            printBtn.onclick = () => this.printInvoiceDirect(sale.id || sale.invoiceNumber);
          }

          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          if (appObj && typeof appObj.openModal === 'function') {
            appObj.openModal('invoice-modal');
          }
        }

        printInvoiceDirect(saleId) {
          const sales = storage.getSales();
          const sale = sales.find(s => (s.id && s.id === saleId) || (s.invoiceNumber && s.invoiceNumber === saleId));
          if (!sale) return;

          const container = document.getElementById('printable-invoice');
          if (container) {
            container.innerHTML = this.buildInvoiceTemplate(sale, storage.getSettings());
          }
          setTimeout(() => { window.print(); }, 250);
        }

        openEditSaleModal(saleId) {
          const sales = storage.getSales();
          const sale = sales.find(s => (s.id && s.id === saleId) || (s.invoiceNumber && s.invoiceNumber === saleId));
          if (!sale) return;

          const settings = storage.getSettings();
          document.getElementById('edit-sale-id').value = sale.id || sale.invoiceNumber;
          document.getElementById('es-invoice-num').textContent = sale.invoiceNumber;
          document.getElementById('es-date').textContent = `${sale.date} ${sale.time || ''}`;
          document.getElementById('es-customer-name').textContent = `${sale.customerName} ${sale.customerShop ? '(' + sale.customerShop + ')' : ''}`;
          document.getElementById('es-net-amount').textContent = Utils.formatCurrency(sale.netAmount, settings.currency);
          document.getElementById('es-net-amount').dataset.netAmount = sale.netAmount;
          document.getElementById('es-paid-amount').value = sale.paidAmount;
          document.getElementById('es-payment-method').value = sale.paymentMethod || 'Cash';
          document.getElementById('es-notes').value = sale.notes || '';

          this.calculateEditSaleBalance();
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          if (appObj && typeof appObj.openModal === 'function') appObj.openModal('edit-sale-modal');
        }

        calculateEditSaleBalance() {
          const netElem = document.getElementById('es-net-amount');
          if (!netElem) return;
          const netAmount = parseFloat(netElem.dataset.netAmount) || 0;
          const paidInput = document.getElementById('es-paid-amount');
          const paidAmount = Math.max(0, parseFloat(paidInput ? paidInput.value : 0) || 0);

          const remaining = Math.max(0, netAmount - paidAmount);
          const settings = storage.getSettings();

          const remElem = document.getElementById('es-remaining-balance');
          if (remElem) remElem.value = Utils.formatCurrency(remaining, settings.currency);

          const statusElem = document.getElementById('es-status-display');
          if (statusElem) {
            const status = remaining <= 0 ? 'Paid' : (paidAmount > 0 ? 'Partially Paid' : 'Unpaid');
            statusElem.value = status;
            statusElem.style.color = remaining <= 0 ? '#10b981' : (paidAmount > 0 ? '#f59e0b' : '#ef4444');
          }
        }

        saveEditSaleForm(e) {
          if (e) e.preventDefault();
          const saleId = document.getElementById('edit-sale-id').value;
          const paidAmount = parseFloat(document.getElementById('es-paid-amount').value) || 0;
          const paymentMethod = document.getElementById('es-payment-method').value || 'Cash';
          const notes = document.getElementById('es-notes').value || '';

          const updatedSale = storage.updateSalePayment(saleId, paidAmount, paymentMethod, notes);
          if (updatedSale) {
            const settings = storage.getSettings();
            const appObj = window.app || (typeof app !== 'undefined' ? app : null);
            if (appObj) {
              if (typeof appObj.showToast === 'function') appObj.showToast(`Invoice ${updatedSale.invoiceNumber} payment updated! Remaining balance: ${Utils.formatCurrency(updatedSale.remainingBalance, settings.currency)}`, 'success');
              if (typeof appObj.closeModal === 'function') appObj.closeModal('edit-sale-modal');
            }
            this.renderSalesHistory();
            if (appObj && typeof appObj.refreshCurrentView === 'function') appObj.refreshCurrentView();
          }
        }

        deleteSale(saleId) {
          const sales = storage.getSales();
          const sale = sales.find(s => (s.id && s.id === saleId) || (s.invoiceNumber && s.invoiceNumber === saleId));
          if (!sale) return;

          const invName = sale.invoiceNumber || saleId;
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);

          const proceedDelete = () => {
            storage.deleteSale(sale.id || sale.invoiceNumber);
            if (appObj && typeof appObj.showToast === 'function') {
              appObj.showToast(`Invoice ${invName} deleted & inventory restored!`, 'info');
            }
            this.renderSalesHistory();
            if (appObj && typeof appObj.refreshCurrentView === 'function') {
              appObj.refreshCurrentView();
            }
          };

          if (appObj && typeof appObj.confirmDelete === 'function') {
            appObj.confirmDelete(`Are you sure you want to delete Invoice ${invName}? Sold item quantities will be restored back to inventory stock.`, proceedDelete);
          } else if (typeof confirm !== 'undefined' ? confirm(`Are you sure you want to delete Invoice ${invName}?`) : true) {
            proceedDelete();
          }
        }

        buildInvoiceTemplate(sale, settings) {
          let itemsRows = '';
          let totalQtySum = 0;
          let totalBnsSum = 0;
          let totalOverallQty = 0;

          (sale.items || []).forEach((item, idx) => {
            const q = parseInt(item.quantity) || 0;
            const bns = parseInt(item.bonus) || 0;
            const totQty = item.totalQty || (q + bns);
            totalQtySum += q;
            totalBnsSum += bns;
            totalOverallQty += totQty;

            const unitPrice = parseFloat(item.price) || 0;
            const tp = parseFloat(item.tp) || 0;
            const dis = parseFloat(item.discountPercent) || 0;
            const ext = parseFloat(item.extPercent) || 0;
            const tax = parseFloat(item.taxPercent) || 0;

            const calc = Utils.calcWholesaleLine ? Utils.calcWholesaleLine(q, unitPrice, bns, dis, ext, tax, tp) : {
              netUnitPrice: unitPrice, lineAmount: parseFloat(item.totalAmount) || 0
            };

            const disText = dis > 0 ? `${dis}%` : '-';
            const extText = ext > 0 ? `${ext}%` : '-';
            const taxText = tax > 0 ? `${tax}%` : '-';

            itemsRows += `
            <tr style="border-bottom: 1px solid #e2e8f0; font-size: 0.78rem;">
              <td style="padding: 5px 4px; text-align: center; color: #64748b;">${idx + 1}</td>
              <td style="padding: 5px 4px; font-weight: 700; color: #0284c7;">${item.code || item.itemNo || 'MED'}</td>
              <td style="padding: 5px 4px; font-weight: 700; color: #0f172a;">${item.name}</td>
              <td style="padding: 5px 4px; text-align: center; color: #475569;">${item.packSize || '-'}</td>
              <td style="padding: 5px 4px; text-align: center; font-size: 0.72rem; color: #334155;">${item.batchNumber || '-'}<br><span style="color:#94a3b8">${item.expiryDate || ''}</span></td>
              <td style="padding: 5px 4px; text-align: center; font-weight: 700;">${q}</td>
              <td style="padding: 5px 4px; text-align: center; color: #059669; font-weight: 700;">${bns}</td>
              <td style="padding: 5px 4px; text-align: center; font-weight: 800; color: #0f172a;">${totQty}</td>
              <td style="padding: 5px 4px; text-align: right; color: #64748b;">${Utils.formatCurrency(tp, settings.currency)}</td>
              <td style="padding: 5px 4px; text-align: right;">${Utils.formatCurrency(unitPrice, settings.currency)}</td>
              <td style="padding: 5px 4px; text-align: center; color: #059669;">${disText}</td>
              <td style="padding: 5px 4px; text-align: center; color: #0284c7;">${extText}</td>
              <td style="padding: 5px 4px; text-align: center; color: #d97706;">${taxText}</td>
              <td style="padding: 5px 4px; text-align: right; font-weight: 700;">${Utils.formatCurrency(calc.netUnitPrice || unitPrice, settings.currency)}</td>
              <td style="padding: 5px 4px; text-align: right; font-weight: 800; color: #0f172a;">${Utils.formatCurrency(calc.lineAmount || item.totalAmount, settings.currency)}</td>
            </tr>
          `;
          });

          const amtInWords = Utils.numberToWords ? Utils.numberToWords(sale.netAmount) : "";

          return `
          <div style="max-width: 900px; margin: 0 auto; background: #ffffff; padding: 12px 14px; font-family: 'Inter', system-ui, -apple-system, sans-serif; color: #0f172a; page-break-inside: avoid; break-inside: avoid;">
            
            <!-- TOP BRAND HEADER (CENTERED) -->
            <div style="display: flex; justify-content: center; align-items: center; text-align: center; padding-bottom: 8px;">
              <div style="display: flex; flex-direction: column; gap: 4px; align-items: center; text-align: center;">
                <img src="${MYU_OFFICIAL_LOGO_B64}" style="width: 52px; height: 52px; object-fit: contain; border-radius: 8px; box-shadow: 0 3px 8px rgba(0,0,0,0.15); background: #000; padding: 2px; margin-bottom: 4px;" alt="MYU Wholesale Logo">
                <div>
                  <h2 style="font-size: 1.3rem; font-weight: 800; color: #0f172a; margin: 0; line-height: 1.2;">${settings.shopName || 'MYU Medicine Wholesale'}</h2>
                  <div style="font-size: 0.82rem; color: #475569; margin-top: 2px;">${settings.address || 'Jail Road, Mardan'}</div>
                  <div style="font-size: 0.82rem; color: #475569;">Phone: ${settings.phone || '03445094631'}</div>
                </div>
              </div>
            </div>

            <!-- CENTERED SALE INVOICE TITLE BANNER -->
            <div style="text-align: center; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; padding: 4px 0; margin: 8px 0 12px 0;">
              <h3 style="font-size: 1.05rem; font-weight: 800; color: #0f172a; margin: 0; text-transform: uppercase; letter-spacing: 0.5px;">Wholesale Sale Invoice</h3>
            </div>

            <!-- BILL TO & INVOICE DETAILS GRID -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px;">
                <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; margin-bottom: 4px;">Bill To:</div>
                <div style="font-size: 0.92rem; font-weight: 800; color: #0f172a;">${sale.customerName}</div>
                ${sale.customerShop ? `<div style="font-size: 0.78rem; color: #475569; margin-top: 2px;">${sale.customerShop}</div>` : ''}
              </div>

              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 12px;">
                <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; margin-bottom: 4px;">Invoice Details:</div>
                <div style="font-size: 0.82rem; color: #334155; display: flex; justify-content: space-between; margin-bottom: 2px;">
                  <span>Invoice No:</span> <strong style="color: #0f172a;">${sale.invoiceNumber}</strong>
                </div>
                <div style="font-size: 0.82rem; color: #334155; display: flex; justify-content: space-between;">
                  <span>Date:</span> <strong style="color: #0f172a;">${sale.date} ${sale.time || ''}</strong>
                </div>
              </div>
            </div>

            <!-- ITEMS TABLE WITH WHOLESALE FIELDS -->
            <div style="overflow-x: auto;">
              <table style="width: 100%; border-collapse: collapse; margin-bottom: 12px; font-size: 0.78rem;">
                <thead>
                  <tr style="background: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1;">
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155; width: 25px;">#</th>
                    <th style="padding: 5px 4px; text-align: left; font-weight: 700; color: #334155;">Code</th>
                    <th style="padding: 5px 4px; text-align: left; font-weight: 700; color: #334155;">Product Name</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">P.Size</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">B.No / Exp</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">Qty</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">BNS</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">Total Qty</th>
                    <th style="padding: 5px 4px; text-align: right; font-weight: 700; color: #334155;">TP</th>
                    <th style="padding: 5px 4px; text-align: right; font-weight: 700; color: #334155;">Price</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">Dis%</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">Ext%</th>
                    <th style="padding: 5px 4px; text-align: center; font-weight: 700; color: #334155;">S.Tax%</th>
                    <th style="padding: 5px 4px; text-align: right; font-weight: 700; color: #334155;">Net</th>
                    <th style="padding: 5px 4px; text-align: right; font-weight: 700; color: #334155;">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsRows}
                </tbody>
                <tfoot>
                  <tr style="border-top: 2px solid #cbd5e1; border-bottom: 1px solid #cbd5e1; font-weight: 800; background: #f8fafc;">
                    <td colspan="5" style="padding: 6px 8px; text-align: right; color: #334155;">Totals:</td>
                    <td style="padding: 6px 4px; text-align: center; color: #0f172a;">${totalQtySum}</td>
                    <td style="padding: 6px 4px; text-align: center; color: #059669;">${totalBnsSum}</td>
                    <td style="padding: 6px 4px; text-align: center; color: #0f172a;">${totalOverallQty}</td>
                    <td colspan="6"></td>
                    <td style="padding: 6px 4px; text-align: right; color: #0f172a; font-size: 0.85rem;">${Utils.formatCurrency(sale.netAmount, settings.currency)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <!-- BOTTOM GRID -->
            <div style="display: grid; grid-template-columns: 1fr 1.1fr; gap: 12px; margin-top: 6px;">
              <!-- Left: Terms & Conditions -->
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 12px; align-self: flex-start;">
                <div style="font-size: 0.78rem; font-weight: 700; color: #334155; margin-bottom: 4px;">Terms and Conditions</div>
                <div style="font-size: 0.76rem; color: #64748b; line-height: 1.3;">
                  ${settings.invoiceFooter || 'Thank you for your business. Purchased medicines can be replaced within 7 days if seals are intact.'}
                </div>
              </div>

              <!-- Right Column: Total Box & Signature -->
              <div>
                <!-- Total Summary Card -->
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 12px; margin-bottom: 8px;">
                  <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 6px;">
                    <span style="font-size: 1rem; font-weight: 800; color: #0f172a;">Total Amount:</span>
                    <span style="font-size: 1.15rem; font-weight: 900; color: #0f172a;">${Utils.formatCurrency(sale.netAmount, settings.currency)}</span>
                  </div>
                  <div style="font-size: 0.75rem; color: #64748b; font-style: italic; margin-bottom: 6px; line-height: 1.2;">
                    Amount In Words: ${amtInWords} Only
                  </div>
                  <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: #475569; margin-bottom: 2px;">
                    <span>Received Amount</span>
                    <span style="font-weight: 700; color: #059669;">${Utils.formatCurrency(sale.paidAmount, settings.currency)}</span>
                  </div>
                  <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: #475569;">
                    <span>Remaining Balance</span>
                    <span style="font-weight: 800; color: ${sale.remainingBalance > 0 ? '#ef4444' : '#10b981'};">${Utils.formatCurrency(sale.remainingBalance, settings.currency)}</span>
                  </div>
                </div>

                <!-- Authorized Signature Card -->
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px 12px; text-align: center; margin-top: 10px;">
                  <div style="border-bottom: 1px dashed #94a3b8; height: 30px; margin-bottom: 4px;"></div>
                  <div style="font-size: 0.75rem; font-weight: 700; color: #475569;">Authorized Signature & Stamp</div>
                </div>
              </div>
            </div>
          </div>
        `;
        }

        /* ==================== RETURNS & REFUNDS METHODS ==================== */
        renderReturnsView() {
          const returns = storage.getReturns();
          const settings = storage.getSettings();

          const countElem = document.getElementById('ret-kpi-count');
          const amountElem = document.getElementById('ret-kpi-amount');
          const unitsElem = document.getElementById('ret-kpi-units');

          const totalCount = returns.length;
          const totalAmount = returns.reduce((a, b) => a + (b.totalRefundAmount || 0), 0);
          let totalUnits = 0;
          returns.forEach(r => {
            (r.items || []).forEach(item => { totalUnits += (parseInt(item.returnQty) || 0); });
          });

          if (countElem) countElem.textContent = totalCount;
          if (amountElem) amountElem.textContent = Utils.formatCurrency(totalAmount, settings.currency);
          if (unitsElem) unitsElem.textContent = `${totalUnits} Units`;

          this.renderReturnsHistoryTable(returns);
        }

        renderReturnsHistoryTable(returnsList) {
          const tbody = document.getElementById('returns-history-tbody');
          if (!tbody) return;
          const settings = storage.getSettings();

          if (!returnsList || !returnsList.length) {
            Utils.emptyTable(tbody, 8, 'No sales returns or refunds recorded yet.');
            return;
          }

          let html = '';
          returnsList.slice().reverse().forEach(r => {
            const itemsSummary = (r.items || []).map(i => `${i.name} (${i.returnQty}x)`).join(', ');
            html += `
            <tr>
              <td><strong style="color: var(--primary);">${r.returnNumber}</strong></td>
              <td><span style="font-weight: 700; color: #475569;">${r.invoiceNumber}</span></td>
              <td>${r.date} <span style="font-size: 0.75rem; color: var(--text-muted);">${r.time || ''}</span></td>
              <td><div style="font-weight: 700;">${r.customerName}</div></td>
              <td><div style="max-width: 260px; font-size: 0.82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${itemsSummary}">${itemsSummary}</div></td>
              <td style="font-weight: 800; color: #ef4444;">${Utils.formatCurrency(r.totalRefundAmount, settings.currency)}</td>
              <td>${Utils.badge(r.reason || 'Customer Return')}</td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <button class="btn-secondary-myu btn-sm-myu" onclick="salesModule.viewReturnDetailsModal('${r.id}')" title="View Details / Receipt"><i class="fa-solid fa-eye"></i></button>
                  <button class="btn-danger-myu btn-sm-myu" onclick="salesModule.deleteReturn('${r.id}')" title="Delete Return"><i class="fa-solid fa-trash-can"></i></button>
                </div>
              </td>
            </tr>
          `;
          });
          tbody.innerHTML = html;
        }

        filterReturnsHistory() {
          const searchInput = document.getElementById('ret-search');
          const query = searchInput ? (searchInput.value || '').toLowerCase().trim() : '';
          const returns = storage.getReturns();
          if (!query) {
            this.renderReturnsHistoryTable(returns);
            return;
          }
          const filtered = returns.filter(r => {
            const itemsStr = (r.items || []).map(i => (i.name || '') + ' ' + (i.itemNo || '')).join(' ').toLowerCase();
            return (r.returnNumber || '').toLowerCase().includes(query) ||
              (r.invoiceNumber || '').toLowerCase().includes(query) ||
              (r.customerName || '').toLowerCase().includes(query) ||
              (r.reason || '').toLowerCase().includes(query) ||
              itemsStr.includes(query);
          });
          this.renderReturnsHistoryTable(filtered);
        }

        openReturnModal(saleId = null) {
          try {
            const select = document.getElementById('ret-sale-select');
            const sales = (window.storage && typeof window.storage.getSales === 'function') ? storage.getSales() : (typeof storage !== 'undefined' ? storage.getSales() : []);

            if (select) {
              Utils.populateSelect(select, (sales || []).slice().reverse(), 'invoiceNumber', s => {
                if (!s) return 'Sale Invoice';
                const inv = s.invoiceNumber || s.id || 'MYU-INV';
                const cust = s.customerName || 'Walk-in Customer';
                const dt = s.date || '';
                const amt = Utils.formatCurrency(s.netAmount || s.grandTotal || 0);
                return `${inv} - ${cust} (${dt}) - Total: ${amt}`;
              }, saleId || '', '-- Select Sale Invoice --');
            }

            const form = document.getElementById('return-form');
            if (form && typeof form.reset === 'function') form.reset();

            const dateInput = document.getElementById('ret-date');
            if (dateInput) dateInput.value = Utils.todayStr();

            const summaryBox = document.getElementById('ret-invoice-summary');
            if (summaryBox) summaryBox.style.display = 'none';

            const tbody = document.getElementById('ret-items-tbody');
            if (tbody) {
              tbody.innerHTML = `
              <tr>
                <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 16px;">
                  Select an invoice above to view returnable items.
                </td>
              </tr>
            `;
            }

            const banner = document.getElementById('ret-total-refund-banner');
            if (banner) banner.textContent = Utils.formatCurrency(0);

            if (saleId && select) {
              const matchingSale = (sales || []).find(s => s.id === saleId || s.invoiceNumber === saleId);
              if (matchingSale) {
                select.value = matchingSale.invoiceNumber;
              } else {
                select.value = saleId;
              }
              this.onReturnInvoiceSelected();
            }

          } catch (err) {
            console.error("Error setting up return modal data:", err);
          }

          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          if (appObj && typeof appObj.openModal === 'function') {
            appObj.openModal('return-modal');
          } else {
            const m = document.getElementById('return-modal');
            if (m) { m.style.display = 'flex'; m.classList.add('show'); }
          }
        }

        onReturnInvoiceSelected() {
          const selectElem = document.getElementById('ret-sale-select');
          if (!selectElem) return;
          const invNum = selectElem.value;
          const sales = (window.storage && typeof window.storage.getSales === 'function') ? storage.getSales() : (typeof storage !== 'undefined' ? storage.getSales() : []);
          const sale = (sales || []).find(s => s.invoiceNumber === invNum || s.id === invNum);

          const summaryBox = document.getElementById('ret-invoice-summary');
          const tbody = document.getElementById('ret-items-tbody');
          const settings = storage.getSettings();

          if (!sale) {
            if (summaryBox) summaryBox.style.display = 'none';
            if (tbody) tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 16px;">Select an invoice above to view returnable items.</td></tr>`;
            const banner = document.getElementById('ret-total-refund-banner');
            if (banner) banner.textContent = Utils.formatCurrency(0);
            return;
          }

          const custElem = document.getElementById('ret-info-customer');
          if (custElem) custElem.textContent = sale.customerName || 'Walk-in Customer';
          const dateElem = document.getElementById('ret-info-date');
          if (dateElem) dateElem.textContent = sale.date || '-';
          const netElem = document.getElementById('ret-info-net');
          if (netElem) netElem.textContent = Utils.formatCurrency(sale.netAmount || sale.grandTotal || 0, settings.currency);
          if (summaryBox) summaryBox.style.display = 'block';

          const allReturns = storage.getReturns().filter(r => r.invoiceNumber === sale.invoiceNumber || r.saleId === sale.id);
          const returnedQtyMap = {};
          allReturns.forEach(r => {
            (r.items || []).forEach(ri => {
              const key = ri.productId || ri.itemNo || ri.name;
              if (key) returnedQtyMap[key] = (returnedQtyMap[key] || 0) + (parseInt(ri.returnQty) || 0);
            });
          });

          let html = '';
          (sale.items || []).forEach((item, index) => {
            const itemKey = item.productId || item.itemNo || item.name;
            const soldQty = parseInt(item.quantity) || 0;
            const prevReturned = returnedQtyMap[itemKey] || 0;
            const maxReturnable = Math.max(0, soldQty - prevReturned);
            const unitPrice = parseFloat(item.unitPrice || item.price || item.salePrice) || 0;
            const disc = parseFloat(item.discountPercent || item.discount) || 0;
            const ext = parseFloat(item.extPercent) || 0;
            const tax = parseFloat(item.taxPercent) || 0;
            const q = parseInt(item.quantity) || 1;
            const calc = Utils.calcWholesaleLine ? Utils.calcWholesaleLine(q, unitPrice, item.bonus || 0, disc, ext, tax, item.tp || 0) : null;
            const netUnitPrice = item.netUnitPrice || (calc ? calc.netUnitPrice : (unitPrice * (1 - (disc / 100))));

            html += `
            <tr data-index="${index}" data-product-id="${item.productId || ''}" data-item-no="${item.itemNo || ''}" data-name="${item.name || ''}" data-net-unit-price="${netUnitPrice}" data-cost-price="${item.costPrice || item.tp || 0}">
              <td>
                <div style="font-weight: 700; font-size: 0.85rem;">${item.name || 'Medicine Item'}</div>
                <div style="font-size: 0.75rem; color: var(--text-muted);">${item.itemNo || ''}</div>
              </td>
              <td>${soldQty}</td>
              <td style="color: #f59e0b; font-weight: 600;">${prevReturned}</td>
              <td><strong style="color: ${maxReturnable > 0 ? '#10b981' : '#ef4444'};">${maxReturnable}</strong></td>
              <td>
                <input type="number" class="form-control-myu ret-qty-input" min="0" max="${maxReturnable}" value="0" style="padding: 4px 8px; font-weight: 700;" ${maxReturnable === 0 ? 'disabled' : ''} oninput="salesModule.calculateReturnRefundTotals()">
              </td>
              <td>${Utils.formatCurrency(netUnitPrice, settings.currency)}</td>
              <td style="font-weight: 800; color: #ef4444;" class="ret-line-refund">Rs. 0.00</td>
            </tr>
          `;
          });

          if (tbody) tbody.innerHTML = html;
          this.calculateReturnRefundTotals();
        }

        calculateReturnRefundTotals() {
          const rows = document.querySelectorAll('#ret-items-tbody tr[data-index]');
          let totalRefund = 0;
          const settings = storage.getSettings();

          rows.forEach(row => {
            const qtyInput = row.querySelector('.ret-qty-input');
            const refundTd = row.querySelector('.ret-line-refund');
            const netUnitPrice = parseFloat(row.dataset.netUnitPrice) || 0;
            const maxReturnable = parseInt(qtyInput ? qtyInput.max : 0) || 0;

            let qty = parseInt(qtyInput ? qtyInput.value : 0) || 0;
            if (qty < 0) { qty = 0; qtyInput.value = 0; }
            if (qty > maxReturnable) { qty = maxReturnable; qtyInput.value = maxReturnable; }

            const lineRefund = qty * netUnitPrice;
            totalRefund += lineRefund;

            if (refundTd) refundTd.textContent = Utils.formatCurrency(lineRefund, settings.currency);
          });

          const banner = document.getElementById('ret-total-refund-banner');
          if (banner) banner.textContent = Utils.formatCurrency(totalRefund, settings.currency);
        }

        saveReturnForm() {
          const selectElem = document.getElementById('ret-sale-select');
          const invNum = selectElem ? selectElem.value : '';
          const sales = storage.getSales();
          const sale = sales.find(s => s.invoiceNumber === invNum || s.id === invNum);
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);

          if (!sale) {
            if (appObj) appObj.showToast('Please select a valid sale invoice.', 'warning');
            return;
          }

          const date = (document.getElementById('ret-date') ? document.getElementById('ret-date').value : '') || Utils.todayStr();
          const paymentMethod = (document.getElementById('ret-payment-method') ? document.getElementById('ret-payment-method').value : '') || 'Cash';
          const reason = (document.getElementById('ret-reason') ? document.getElementById('ret-reason').value : '') || 'Customer Return';
          const notes = (document.getElementById('ret-notes') ? document.getElementById('ret-notes').value : '') || '';

          const returnedItems = [];
          let totalRefundAmount = 0;
          let totalProfitReversed = 0;

          const rows = document.querySelectorAll('#ret-items-tbody tr[data-index]');
          rows.forEach(row => {
            const qtyInput = row.querySelector('.ret-qty-input');
            const returnQty = parseInt(qtyInput ? qtyInput.value : 0) || 0;

            if (returnQty > 0) {
              const netUnitPrice = parseFloat(row.dataset.netUnitPrice) || 0;
              const costPrice = parseFloat(row.dataset.costPrice) || 0;
              const lineRefund = returnQty * netUnitPrice;
              const lineProfit = returnQty * (netUnitPrice - costPrice);

              totalRefundAmount += lineRefund;
              totalProfitReversed += lineProfit;

              returnedItems.push({
                productId: row.dataset.productId,
                itemNo: row.dataset.itemNo,
                name: row.dataset.name,
                returnQty: returnQty,
                unitPrice: netUnitPrice,
                lineRefund: lineRefund,
                lineProfitReversed: lineProfit
              });
            }
          });

          if (returnedItems.length === 0) {
            if (appObj) appObj.showToast('Please enter return quantity for at least one item.', 'warning');
            return;
          }

          const returnData = {
            saleId: sale.id,
            invoiceNumber: sale.invoiceNumber,
            date: date,
            customerId: sale.customerId || '',
            customerName: sale.customerName || 'Walk-in Customer',
            items: returnedItems,
            totalRefundAmount: totalRefundAmount,
            totalProfitReversed: totalProfitReversed,
            paymentMethod: paymentMethod,
            reason: reason,
            notes: notes
          };

          const newReturn = storage.addReturn(returnData);
          if (newReturn) {
            if (appObj) {
              appObj.closeModal('return-modal');
              appObj.showToast(`Return ${newReturn.returnNumber} processed successfully! Stock restocked and refund of ${Utils.formatCurrency(totalRefundAmount)} issued.`, 'success');
            }
            this.renderReturnsView();
            if (appObj && typeof appObj.refreshCurrentView === 'function') {
              appObj.refreshCurrentView();
            }
          }
        }

        viewReturnDetailsModal(returnId) {
          const returns = storage.getReturns();
          const ret = returns.find(r => r.id === returnId);
          if (!ret) return;

          this.currentReturnId = returnId;
          const settings = storage.getSettings();
          const container = document.getElementById('return-details-modal-content');
          if (!container) return;

          let itemsHtml = '';
          (ret.items || []).forEach(item => {
            itemsHtml += `
            <tr>
              <td><strong>${item.name}</strong></td>
              <td>${item.returnQty}</td>
              <td>${Utils.formatCurrency(item.unitPrice, settings.currency)}</td>
              <td style="font-weight: 700; color: #ef4444;">${Utils.formatCurrency(item.lineRefund, settings.currency)}</td>
            </tr>
          `;
          });

          container.innerHTML = `
          <div style="padding: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid var(--primary); padding-bottom: 12px; margin-bottom: 16px;">
              <div>
                <h2 style="color: var(--primary); margin: 0; font-size: 1.25rem;">${settings.shopName || 'MYU Wholesale'}</h2>
                <div style="font-size: 0.8rem; color: var(--text-muted);">SALES RETURN & REFUND VOUCHER</div>
              </div>
              <div style="text-align: right;">
                <div style="font-weight: 800; font-size: 1.1rem; color: #ef4444;">${ret.returnNumber}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted);">${ret.date} ${ret.time || ''}</div>
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; font-size: 0.85rem; margin-bottom: 16px; background: #f8fafc; padding: 12px; border-radius: 8px;">
              <div><strong>Original Sale Invoice:</strong> ${ret.invoiceNumber}</div>
              <div><strong>Customer Name:</strong> ${ret.customerName}</div>
              <div><strong>Refund Method:</strong> ${Utils.badge(ret.paymentMethod)}</div>
              <div><strong>Return Reason:</strong> ${ret.reason}</div>
              ${ret.notes ? `<div style="grid-column: 1 / -1;"><strong>Notes:</strong> ${ret.notes}</div>` : ''}
            </div>

            <table class="custom-table" style="font-size: 0.85rem; margin-bottom: 16px;">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Returned Qty</th>
                  <th>Unit Refund Price</th>
                  <th>Subtotal Refund</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
              </tbody>
            </table>

            <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: 8px; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center;">
              <span style="font-weight: 700; color: #991b1b;">TOTAL REFUND AMOUNT ISSUED:</span>
              <span style="font-size: 1.25rem; font-weight: 800; color: #ef4444;">${Utils.formatCurrency(ret.totalRefundAmount, settings.currency)}</span>
            </div>
          </div>
        `;

          app.openModal('return-details-modal');
        }

        triggerPrintReturnVoucher(returnId) {
          const id = returnId || this.currentReturnId;
          const returns = storage.getReturns();
          const ret = returns.find(r => r.id === id || r.returnNumber === id);
          if (!ret) return;

          const container = document.getElementById('printable-invoice');
          if (!container) return;

          const settings = storage.getSettings();
          let itemsHtml = '';
          (ret.items || []).forEach((item, idx) => {
            itemsHtml += `
            <tr style="border-bottom: 1px solid #e2e8f0; font-size: 0.85rem;">
              <td style="padding: 8px; text-align: center; color: #64748b;">${idx + 1}</td>
              <td style="padding: 8px; font-weight: 700; color: #0f172a;">${item.name}</td>
              <td style="padding: 8px; text-align: center; font-weight: 700;">${item.returnQty}</td>
              <td style="padding: 8px; text-align: right; color: #475569;">${Utils.formatCurrency(item.unitPrice, settings.currency)}</td>
              <td style="padding: 8px; text-align: right; font-weight: 800; color: #ef4444;">${Utils.formatCurrency(item.lineRefund, settings.currency)}</td>
            </tr>
          `;
          });

          container.innerHTML = `
          <div style="max-width: 800px; margin: 0 auto; background: #ffffff; padding: 20px; font-family: 'Inter', system-ui, sans-serif; color: #0f172a;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #ef4444; padding-bottom: 12px; margin-bottom: 16px;">
              <div>
                <h2 style="font-size: 1.3rem; font-weight: 800; color: #0f172a; margin: 0;">${settings.shopName || 'MYU Medicine Wholesale'}</h2>
                <div style="font-size: 0.82rem; color: #475569; margin-top: 2px;">${settings.address || 'Jail Road, Mardan'} &bull; Phone: ${settings.phone || '03445094631'}</div>
                <div style="font-size: 0.85rem; font-weight: 800; color: #ef4444; margin-top: 4px; text-transform: uppercase;">Official Sales Return & Refund Voucher</div>
              </div>
              <div style="text-align: right;">
                <h3 style="font-size: 1.15rem; font-weight: 800; color: #ef4444; margin: 0;">${ret.returnNumber}</h3>
                <div style="font-size: 0.8rem; color: #64748b; margin-top: 4px;">Ref Inv: <strong>${ret.invoiceNumber}</strong></div>
                <div style="font-size: 0.8rem; color: #64748b;">Date: ${ret.date} ${ret.time || ''}</div>
              </div>
            </div>

            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; margin-bottom: 16px; font-size: 0.85rem; display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <div><strong>Customer Name:</strong> ${ret.customerName}</div>
              <div><strong>Refund Method:</strong> ${ret.paymentMethod || 'Cash'}</div>
              <div><strong>Reason for Return:</strong> ${ret.reason}</div>
              ${ret.notes ? `<div><strong>Notes:</strong> ${ret.notes}</div>` : ''}
            </div>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px;">
              <thead>
                <tr style="background: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1; font-size: 0.8rem; text-transform: uppercase; color: #475569;">
                  <th style="padding: 8px; text-align: center;">#</th>
                  <th style="padding: 8px; text-align: left;">Returned Medicine</th>
                  <th style="padding: 8px; text-align: center;">Returned Qty</th>
                  <th style="padding: 8px; text-align: right;">Unit Net Price</th>
                  <th style="padding: 8px; text-align: right;">Line Refund</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
              </tbody>
            </table>

            <div style="background: #fef2f2; border: 1px solid #fca5a5; border-radius: 6px; padding: 12px 16px; display: flex; justify-content: space-between; align-items: center;">
              <span style="font-weight: 800; color: #991b1b;">TOTAL REFUND ISSUED:</span>
              <span style="font-size: 1.3rem; font-weight: 900; color: #ef4444;">${Utils.formatCurrency(ret.totalRefundAmount, settings.currency)}</span>
            </div>

            <div style="display: flex; justify-content: space-between; margin-top: 40px; padding-top: 12px; border-top: 1px dashed #cbd5e1; font-size: 0.78rem; color: #64748b;">
              <div>Customer Signature: __________________</div>
              <div>Authorized Representative: __________________</div>
            </div>
          </div>
        `;

          setTimeout(() => { window.print(); }, 250);
        }

        deleteReturn(id) {
          const appObj = window.app || (typeof app !== 'undefined' ? app : null);
          const proceedDelete = () => {
            storage.deleteReturn(id);
            if (appObj && typeof appObj.showToast === 'function') appObj.showToast('Return record deleted & stock adjusted.', 'info');
            this.renderReturnsView();
            if (appObj && typeof appObj.refreshCurrentView === 'function') appObj.refreshCurrentView();
          };

          if (appObj && typeof appObj.confirmDelete === 'function') {
            appObj.confirmDelete('Are you sure you want to delete this sales return record? Restocked items will be deducted back from inventory.', proceedDelete);
          } else if (typeof confirm !== 'undefined' ? confirm('Are you sure you want to delete this sales return record?') : true) {
            proceedDelete();
          }
        }
      }

      var salesModule = window.salesModule || new SalesModule();


      /* ==================== PROFIT & LOSS & EXPENSES MODULE ==================== */

if (typeof global !== 'undefined') {
  global.SalesModule = SalesModule;
}
if (typeof window !== 'undefined') {
  window.SalesModule = SalesModule;
  window.salesModule = window.salesModule || new SalesModule();
}

SalesModule.prototype.openCustomerModal = function(customerId = null) {
  const form = document.getElementById('customer-form');
  if (form) form.reset();
  const idInput = document.getElementById('cust-id');
  if (idInput) idInput.value = '';
  const titleElem = document.getElementById('customer-modal-title');
  if (titleElem) titleElem.textContent = 'Add New Customer / Pharmacy';

  if (customerId) {
    const cust = storage.getCustomers().find(c => c.id === customerId);
    if (cust) {
      if (titleElem) titleElem.textContent = 'Edit Customer Details';
      if (idInput) idInput.value = cust.id;
      const nInput = document.getElementById('cust-name'); if (nInput) nInput.value = cust.name;
      const sInput = document.getElementById('cust-shop-name'); if (sInput) sInput.value = cust.shopName || '';
      const pInput = document.getElementById('cust-phone'); if (pInput) pInput.value = cust.phone || '';
      const aInput = document.getElementById('cust-address'); if (aInput) aInput.value = cust.address || '';
    }
  }

  const appObj = window.app || (typeof app !== 'undefined' ? app : null);
  if (appObj && typeof appObj.openModal === 'function') appObj.openModal('customer-modal');
};

SalesModule.prototype.openCustomerPaymentModal = function() {
  const select = document.getElementById('cpay-customer-select');
  const customers = storage.getCustomers();
  const settings = storage.getSettings();
  if (select) {
    Utils.populateSelect(select, customers, 'id', c => `${c.name} (${c.shopName || 'Retail'}) - Bal: ${Utils.formatCurrency(c.remainingBalance, settings.currency)}`);
  }
  
  const form = document.getElementById('customer-payment-form');
  if (form) form.reset();
  const dInput = document.getElementById('cpay-date');
  if (dInput) dInput.value = Utils.todayStr();
  
  const appObj = window.app || (typeof app !== 'undefined' ? app : null);
  if (appObj && typeof appObj.openModal === 'function') appObj.openModal('customer-payment-modal');
};

SalesModule.prototype.openCustomerPaymentModalForCust = function(customerId) {
  this.openCustomerPaymentModal();
  const select = document.getElementById('cpay-customer-select');
  if (select) select.value = customerId;
};
