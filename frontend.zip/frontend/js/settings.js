/* ==================== SETTINGS & BACKUP/RESTORE MODULE ==================== */
class SettingsModule {
  constructor() {}

  loadSettingsForm() {
    const s = storage.getSettings();
    if (document.getElementById('set-shop-name')) document.getElementById('set-shop-name').value = s.shopName || '';
    if (document.getElementById('set-tagline')) document.getElementById('set-tagline').value = s.tagline || '';
    if (document.getElementById('set-address')) document.getElementById('set-address').value = s.address || '';
    if (document.getElementById('set-phone')) document.getElementById('set-phone').value = s.phone || '';
    if (document.getElementById('set-whatsapp')) document.getElementById('set-whatsapp').value = s.whatsapp || '';
    if (document.getElementById('set-email')) document.getElementById('set-email').value = s.email || '';
    if (document.getElementById('set-currency')) document.getElementById('set-currency').value = s.currency || 'Rs.';
    if (document.getElementById('set-min-stock')) document.getElementById('set-min-stock').value = s.minStockAlert || 10;
    if (document.getElementById('set-invoice-footer')) document.getElementById('set-invoice-footer').value = s.invoiceFooter || '';
  }

  saveSettingsForm(event) {
    if (event) event.preventDefault();
    const data = {
      shopName: document.getElementById('set-shop-name').value,
      tagline: document.getElementById('set-tagline').value,
      address: document.getElementById('set-address').value,
      phone: document.getElementById('set-phone').value,
      whatsapp: document.getElementById('set-whatsapp').value,
      email: document.getElementById('set-email').value,
      currency: document.getElementById('set-currency').value || 'Rs.',
      minStockAlert: parseInt(document.getElementById('set-min-stock').value) || 10,
      invoiceFooter: document.getElementById('set-invoice-footer').value
    };

    storage.saveSettings(data);
    const appObj = window.app || (typeof app !== 'undefined' ? app : null);
    if (appObj) {
      appObj.loadShopBranding();
      appObj.showToast('Shop branding & business settings updated successfully.', 'success');
    }
  }

  exportBackupJson() {
    const backupObj = storage.exportAllDataJson();
    const str = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupObj, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute("href", str);
    dlAnchor.setAttribute("download", `MYU_Wholesale_Backup_${Utils.todayStr()}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();

    const appObj = window.app || (typeof app !== 'undefined' ? app : null);
    if (appObj) appObj.showToast('Backup file downloaded successfully.', 'success');
  }

  triggerRestoreFileInput() {
    document.getElementById('restore-file-input')?.click();
  }

  handleRestoreFile(fileInput) {
    const appObj = window.app || (typeof app !== 'undefined' ? app : null);
    if (!fileInput.files || !fileInput.files[0]) return;

    const file = fileInput.files[0];
    var reader = window.reader || new FileReader();

    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (appObj) {
          appObj.confirmDelete('Are you sure you want to restore data from this backup? Current data will be replaced. A safety backup will be created.', () => {
            // Create safety snapshot
            this.exportBackupJson();

            const ok = storage.importAllDataJson(data);
            if (ok) {
              appObj.showToast('Database restored successfully from backup!', 'success');
              appObj.loadShopBranding();
              appObj.refreshCurrentView();
            } else {
              appObj.showToast('Invalid backup file format.', 'danger');
            }
          });
        }
      } catch (err) {
        if (appObj) appObj.showToast('Error reading backup file: Invalid JSON format.', 'danger');
      }
    };

    reader.readAsText(file);
  }

  clearAllDataDemo() {
    const appObj = window.app || (typeof app !== 'undefined' ? app : null);
    if (appObj) {
      appObj.confirmDelete('CRITICAL WARNING: Are you sure you want to CLEAR ALL BUSINESS DATA? All products, invoices, customers and ledgers will be permanently deleted.', () => {
        // Create safety backup before clearing
        this.exportBackupJson();
        storage.clearAllBusinessData();
        appObj.showToast('All business data cleared.', 'info');
        appObj.refreshCurrentView();
      });
    }
  }
}

var settingsModule = window.settingsModule || new SettingsModule();
window.settingsModule = settingsModule;
